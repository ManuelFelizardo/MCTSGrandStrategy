package games.strategy.triplea.ai.mctsclean.util;

import games.strategy.engine.data.GameData;
import games.strategy.engine.data.GameMap;
import games.strategy.engine.data.GamePlayer;
import games.strategy.engine.data.MoveDescription;
import games.strategy.engine.data.Route;
import games.strategy.engine.data.Territory;
import games.strategy.engine.data.Unit;
import games.strategy.engine.delegate.IDelegateBridge;
import games.strategy.triplea.ai.AbstractAi;
import games.strategy.triplea.ai.mctsclean.algorithm.Mcts;
import games.strategy.triplea.ai.mctsclean.algorithm.NewAction;
import games.strategy.triplea.ai.mctsclean.oepMcts.OepAction;
import games.strategy.triplea.ai.mctsclean.oepMcts.OepAction2;
import games.strategy.triplea.ai.pro.logging.ProLogger;
import games.strategy.triplea.ai.pro.util.ProMatches;
import games.strategy.triplea.ai.weak.WeakAi;
import games.strategy.triplea.delegate.Matches;
import games.strategy.triplea.delegate.remote.IMoveDelegate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.triplea.util.Tuple;

public class ForwardModel {

    public static WeakAi mctsAi;

    private ForwardModel(){

    };

    public static void doMove(
        final GameData data, final List<MoveDescription> moves, final IMoveDelegate moveDel, boolean isSimulation) {
        //ProLogger.info("moves size "+moves.size());
        //long time=System.currentTimeMillis();
        if(isSimulation){
            final IDelegateBridge bridge =new MctsDummyDelegateBridge(mctsAi, data.getSequence().getStep().getPlayerId(), data);
            moveDel.setDelegateBridgeAndPlayer(bridge);
        }

        // Group non-amphib units of the same type moving on the same route
        String moves2=moves.toString();
        String moves3="";
        for (Territory t:data.getMap().getTerritories()){
            moves3+=t.getName()+" : ";
            moves3+=t.getUnits();
            moves3+="\n\n";
        }

        // TODO: #5499 Use MoveBatcher here - or ideally at the time the moves are being generated.
        final boolean noTransportLoads =
            moves.stream().allMatch(move -> move.getUnitsToTransports().isEmpty());

        if (noTransportLoads) {
            for (int i = 0; i < moves.size(); i++) {
                final Route r = moves.get(i).getRoute();
                for (int j = i + 1; j < moves.size(); j++) {
                    final Route r2 = moves.get(j).getRoute();
                    if (r.equals(r2)) {
                        final var mergedUnits = new ArrayList<Unit>();
                        mergedUnits.addAll(moves.get(j).getUnits());
                        mergedUnits.addAll(moves.get(i).getUnits());
                        moves.set(j, new MoveDescription(mergedUnits, r));
                        moves.remove(i);
                        i--;
                        break;
                    }
                }
            }
        }

        //ProLogger.info("merge moves time - "+(System.currentTimeMillis()-time));
        //time=System.currentTimeMillis();


        // Move units
        for (final MoveDescription move : moves) {
            /*
            MovePerformer tempMovePerformer = new MovePerformer();
            tempMovePerformer.initialize((MoveDelegate) moveDel);
            tempMovePerformer.moveUnits(move, data.getSequence().getStep().getPlayerId(), new UndoableMove(move.getUnits(), move.getRoute()));
             */
            final String result = moveDel.performMove(move);
            //ProLogger.info("performed move "+move.toString());
            //ProLogger.info("performed move do move");
            if (result != null && isSimulation && data.getSequence().getStep().getName().endsWith("NonCombatMove")) {
                ProLogger.warn(
                    data.getSequence().getRound()
                        + "-"
                        + data.getSequence().getStep().getName()
                        + ": could not move "
                        + move.getUnits()
                        + " over "
                        + move.getRoute()
                        + " because: "
                        + result);

                throw new NullPointerException(data.getSequence().getRound()
                    + "-"
                    + data.getSequence().getStep().getName()
                    + ": could not move "
                    + move.getUnits()
                    + " over "
                    + move.getRoute()
                    + " because: "
                    + result+"\n\n---"+moves.toString()+"\n\n---"+moves2+"\n\n"+moves3+"\n\n---"+"\n\n\n--- iterations - "+ Mcts.iterations);
            }
            if (!isSimulation) {
                AbstractAi.movePause();
            }
        }
        //ProLogger.info("execute moves time - "+(System.currentTimeMillis()-time));
    }


    public static List<MoveDescription> calculateMoveRoutes(
        final MctsData mctsData,
        final GamePlayer player,
        final ModelTerritory modelTerritory) {

        final GameData data = mctsData.getData();
        final GameMap map = data.getMap();
        boolean isCombatMove;
        if (data.getSequence().getStep().getName().endsWith("NonCombatMove")){
            isCombatMove=false;
        } else {
            isCombatMove=true;
        }

        final var moves = new ArrayList<MoveDescription>();
        // Loop through each unit that is attacking the current territory
        Tuple<Territory, Unit> lastLandTransport = Tuple.of(null, null);
        for (final Unit u : modelTerritory.getUnits()) {



            // Skip if unit is already in move to territory
            final Territory startTerritory = mctsData.getUnitTerritory(u);
            if (startTerritory == null || startTerritory.equals(modelTerritory.getTerritory())) {
                continue;
            }

            // Add unit to move list
            final var unitList = new ArrayList<Unit>();
            unitList.add(u);
            if (Matches.unitIsLandTransport().test(u)) {
                lastLandTransport = Tuple.of(startTerritory, u);
            }

            // Determine route and add to move list
            Route route = null;
            if (!unitList.isEmpty() && unitList.stream().allMatch(Matches.unitIsLand())) {

                // Land unit
                route =
                    map.getRouteForUnit(
                        startTerritory,
                        modelTerritory.getTerritory(),
                        ProMatches.territoryCanMoveLandUnitsThrough(
                            player, data, u, startTerritory, isCombatMove, List.of()),
                        u,
                        player);
                if (route == null && startTerritory.equals(lastLandTransport.getFirst())) {
                    route =
                        map.getRouteForUnit(
                            startTerritory,
                            modelTerritory.getTerritory(),
                            ProMatches.territoryCanMoveLandUnitsThrough(
                                player,
                                data,
                                lastLandTransport.getSecond(),
                                startTerritory,
                                isCombatMove,
                                List.of()),
                            u,
                            player);
                }
            } else if (!unitList.isEmpty() && unitList.stream().allMatch(Matches.unitIsAir())) {

                // Air unit
                route =
                    map.getRouteForUnit(
                        startTerritory,
                        modelTerritory.getTerritory(),
                        ProMatches.territoryCanMoveAirUnitsAndNoAa(player, data, isCombatMove),
                        u,
                        player);
            }
            if (route == null) {
                ProLogger.warn(
                    data.getSequence().getRound()
                        + "-"
                        + data.getSequence().getStep().getName()
                        + ": route is null (could not calculate route)"
                        + startTerritory
                        + " to "
                        + modelTerritory.getTerritory()
                        + ", units="
                        + unitList);
            } else {
                moves.add(new MoveDescription(unitList, route));
            }
        }
        return moves;
    }

    /*
    public static List<MoveDescription> calculateMoveRoutes(
        final MctsData mctsData,
        final GamePlayer player,
        final ArrayList<Action> actions) {

        final GameData data = mctsData.getData();
        final GameMap map = data.getMap();
        boolean isCombatMove;
        if (data.getSequence().getStep().getName().endsWith("NonCombatMove")){
            isCombatMove=false;
        } else {
            isCombatMove=true;
        }

        final var moves = new ArrayList<MoveDescription>();
        // Loop through each unit that is attacking the current territory
        Tuple<Territory, Unit> lastLandTransport = Tuple.of(null, null);
        for(Action a:actions) {
            ModelTerritory modelTerritory=a.getMove();
            for (final Unit u : modelTerritory.getUnits()) {


                // Skip if unit is already in move to territory
                final Territory startTerritory = mctsData.getUnitTerritory(u);
                if (startTerritory == null || startTerritory.equals(modelTerritory.getTerritory())) {
                    continue;
                }

                // Add unit to move list
                final var unitList = new ArrayList<Unit>();
                unitList.add(u);
                if (Matches.unitIsLandTransport().test(u)) {
                    lastLandTransport = Tuple.of(startTerritory, u);
                }

                // Determine route and add to move list
                Route route = null;

                if (!unitList.isEmpty() && unitList.stream().allMatch(Matches.unitIsLand())) {

                    // Land unit
                    route =
                        map.getRouteForUnit(
                            startTerritory,
                            modelTerritory.getTerritory(),
                            ProMatches.territoryCanMoveLandUnitsThrough(
                                player, data, u, startTerritory, isCombatMove, List.of()),
                            u,
                            player);
                    if (route == null && startTerritory.equals(lastLandTransport.getFirst())) {
                        route =
                            map.getRouteForUnit(
                                startTerritory,
                                modelTerritory.getTerritory(),
                                ProMatches.territoryCanMoveLandUnitsThrough(
                                    player,
                                    data,
                                    lastLandTransport.getSecond(),
                                    startTerritory,
                                    isCombatMove,
                                    List.of()),
                                u,
                                player);
                    }
                } else if (!unitList.isEmpty() && unitList.stream().allMatch(Matches.unitIsAir())) {

                    // Air unit
                    route =
                        map.getRouteForUnit(
                            startTerritory,
                            modelTerritory.getTerritory(),
                            ProMatches.territoryCanMoveAirUnitsAndNoAa(player, data, isCombatMove),
                            u,
                            player);
                }
                if (route == null) {
                    ProLogger.warn(
                        data.getSequence().getRound()
                            + "-"
                            + data.getSequence().getStep().getName()
                            + ": route is null (could not calculate route)"
                            + startTerritory
                            + " to "
                            + modelTerritory.getTerritory()
                            + ", units="
                            + unitList);
                } else {
                    moves.add(new MoveDescription(unitList, route));
                }
            }

        }

        return moves;
    }
     */

    public static List<MoveDescription> calculateMoveRoutes(
        final MctsData mctsData,
        final GamePlayer player,
        final ArrayList<NewAction> actions) {

        final GameData data = mctsData.getData();
        final GameMap map = data.getMap();
        boolean isCombatMove;
        if (data.getSequence().getStep().getName().endsWith("NonCombatMove")){
            isCombatMove=false;
        } else {
            isCombatMove=true;
        }

        final var moves = new ArrayList<MoveDescription>();
        // Loop through each unit that is attacking the current territory
        Tuple<Territory, Unit> lastLandTransport = Tuple.of(null, null);
        for(NewAction a:actions) {
            for (final Unit u : a.getUnits()) {


                // Skip if unit is already in move to territory
                final Territory startTerritory = mctsData.getUnitTerritory(u);
                if (startTerritory == null || startTerritory.equals(a.getT())) {
                    continue;
                }

                // Add unit to move list
                final var unitList = new ArrayList<Unit>();
                unitList.add(u);
                if (Matches.unitIsLandTransport().test(u)) {
                    lastLandTransport = Tuple.of(startTerritory, u);
                }

                // Determine route and add to move list
                Route route = null;

                if (!unitList.isEmpty() && unitList.stream().allMatch(Matches.unitIsLand())) {

                    // Land unit
                    route =
                        map.getRouteForUnit(
                            startTerritory,
                            a.getT(),
                            ProMatches.territoryCanMoveLandUnitsThrough(
                                player, data, u, startTerritory, isCombatMove, List.of()),
                            u,
                            player);
                    if (route == null && startTerritory.equals(lastLandTransport.getFirst())) {
                        route =
                            map.getRouteForUnit(
                                startTerritory,
                                a.getT(),
                                ProMatches.territoryCanMoveLandUnitsThrough(
                                    player,
                                    data,
                                    lastLandTransport.getSecond(),
                                    startTerritory,
                                    isCombatMove,
                                    List.of()),
                                u,
                                player);
                    }
                } else if (!unitList.isEmpty() && unitList.stream().allMatch(Matches.unitIsAir())) {

                    // Air unit
                    route =
                        map.getRouteForUnit(
                            startTerritory,
                            a.getT(),
                            ProMatches.territoryCanMoveAirUnitsAndNoAa(player, data, isCombatMove),
                            u,
                            player);
                }
                if (route == null) {
                    ProLogger.warn(
                        data.getSequence().getRound()
                            + "-"
                            + data.getSequence().getStep().getName()
                            + ": route is null (could not calculate route)"
                            + startTerritory
                            + " to "
                            + a.getT()
                            + ", units="
                            + unitList);
                } else {
                    moves.add(new MoveDescription(unitList, route));
                }
            }

        }

        return moves;
    }

    public static List<MoveDescription> calculateMoveRoutesOep2(
        final MctsData mctsData,
        final GamePlayer player,
        final ArrayList<OepAction2> actions) {

        final GameData data = mctsData.getData();
        final GameMap map = data.getMap();
        boolean isCombatMove;
        if (data.getSequence().getStep().getName().endsWith("NonCombatMove")){
            isCombatMove=false;
        } else {
            isCombatMove=true;
        }

        final var moves = new ArrayList<MoveDescription>();
        // Loop through each unit that is attacking the current territory
        Tuple<Territory, Unit> lastLandTransport = Tuple.of(null, null);
        for(OepAction2 a:actions) {
            for (final Unit u : a.getUnits()) {


                // Skip if unit is already in move to territory
                final Territory startTerritory = mctsData.getUnitTerritory(u);
                if (startTerritory == null || startTerritory.equals(a.getT())) {
                    continue;
                }

                // Add unit to move list
                final var unitList = new ArrayList<Unit>();
                unitList.add(u);
                if (Matches.unitIsLandTransport().test(u)) {
                    lastLandTransport = Tuple.of(startTerritory, u);
                }

                // Determine route and add to move list
                Route route = null;

                if (!unitList.isEmpty() && unitList.stream().allMatch(Matches.unitIsLand())) {

                    // Land unit
                    route =
                        map.getRouteForUnit(
                            startTerritory,
                            a.getT(),
                            ProMatches.territoryCanMoveLandUnitsThrough(
                                player, data, u, startTerritory, isCombatMove, List.of()),
                            u,
                            player);
                    if (route == null && startTerritory.equals(lastLandTransport.getFirst())) {
                        route =
                            map.getRouteForUnit(
                                startTerritory,
                                a.getT(),
                                ProMatches.territoryCanMoveLandUnitsThrough(
                                    player,
                                    data,
                                    lastLandTransport.getSecond(),
                                    startTerritory,
                                    isCombatMove,
                                    List.of()),
                                u,
                                player);
                    }
                } else if (!unitList.isEmpty() && unitList.stream().allMatch(Matches.unitIsAir())) {

                    // Air unit
                    route =
                        map.getRouteForUnit(
                            startTerritory,
                            a.getT(),
                            ProMatches.territoryCanMoveAirUnitsAndNoAa(player, data, isCombatMove),
                            u,
                            player);
                }
                if (route == null) {
                    ProLogger.warn(
                        data.getSequence().getRound()
                            + "-"
                            + data.getSequence().getStep().getName()
                            + ": route is null (could not calculate route)"
                            + startTerritory
                            + " to "
                            + a.getT()
                            + ", units="
                            + unitList);
                } else {
                    moves.add(new MoveDescription(unitList, route));
                }
            }

        }

        return moves;
    }

    public static List<MoveDescription> calculateMoveRoutesOep(
        final MctsData mctsData,
        final GamePlayer player,
        GameData data,
        final ArrayList<OepAction> actions) {
        //long time= System.currentTimeMillis();
        final GameMap map = data.getMap();
        boolean isCombatMove;
        if (data.getSequence().getStep().getName().endsWith("NonCombatMove")){
            isCombatMove=false;
        } else {
            isCombatMove=true;
        }

        final var moves = new ArrayList<MoveDescription>();
        // Loop through each unit that is attacking the current territory
        Tuple<Territory, Unit> lastLandTransport = Tuple.of(null, null);
        for(OepAction a:actions) {
            a=a.replace(data);
            Unit u=a.getU();

                // Skip if unit is already in move to territory
                final Territory startTerritory = mctsData.getUnitTerritory(u);
                if (startTerritory == null || startTerritory.equals(a.getT())) {
                    continue;
                }

                // Add unit to move list
                final var unitList = new ArrayList<Unit>();
                unitList.add(u);
                if (Matches.unitIsLandTransport().test(u)) {
                    lastLandTransport = Tuple.of(startTerritory, u);
                }

                // Determine route and add to move list
                Route route = null;

                if (!unitList.isEmpty() && unitList.stream().allMatch(Matches.unitIsLand())) {

                    // Land unit
                    route =
                        map.getRouteForUnit(
                            startTerritory,
                            a.getT(),
                            ProMatches.territoryCanMoveLandUnitsThrough(
                                player, data, u, startTerritory, isCombatMove, List.of()),
                            u,
                            player);
                    if (route == null && startTerritory.equals(lastLandTransport.getFirst())) {
                        route =
                            map.getRouteForUnit(
                                startTerritory,
                                a.getT(),
                                ProMatches.territoryCanMoveLandUnitsThrough(
                                    player,
                                    data,
                                    lastLandTransport.getSecond(),
                                    startTerritory,
                                    isCombatMove,
                                    List.of()),
                                u,
                                player);
                    }
                } else if (!unitList.isEmpty() && unitList.stream().allMatch(Matches.unitIsAir())) {

                    // Air unit
                    route =
                        map.getRouteForUnit(
                            startTerritory,
                            a.getT(),
                            ProMatches.territoryCanMoveAirUnitsAndNoAa(player, data, isCombatMove),
                            u,
                            player);
                }
                if (route == null) {
                    ProLogger.warn(
                        data.getSequence().getRound()
                            + "-"
                            + data.getSequence().getStep().getName()
                            + ": route is null (could not calculate route)"
                            + startTerritory
                            + " to "
                            + a.getT()
                            + ", units="
                            + unitList);
                } else {
                    moves.add(new MoveDescription(unitList, route));
                }
            }

        //ProLogger.info("calculate routes time - "+(System.currentTimeMillis()-time));
        return moves;
    }

    public static List<MoveDescription> calculateMoveRoutesNew(
        final MctsData mctsData,
        final GamePlayer player,
        final Territory t,
        Set<Unit> units) {

        final GameData data = mctsData.getData();
        final GameMap map = data.getMap();
        boolean isCombatMove;
        if (data.getSequence().getStep().getName().endsWith("NonCombatMove")){
            isCombatMove=false;
        } else {
            isCombatMove=true;
        }

        final var moves = new ArrayList<MoveDescription>();
        // Loop through each unit that is attacking the current territory
        Tuple<Territory, Unit> lastLandTransport = Tuple.of(null, null);
        for (final Unit u : units) {



            // Skip if unit is already in move to territory
            final Territory startTerritory = mctsData.getUnitTerritory(u);
            if (startTerritory == null || startTerritory.equals(t)) {
                continue;
            }

            // Add unit to move list
            final var unitList = new ArrayList<Unit>();
            unitList.add(u);
            if (Matches.unitIsLandTransport().test(u)) {
                lastLandTransport = Tuple.of(startTerritory, u);
            }

            // Determine route and add to move list
            Route route = null;
            if (!unitList.isEmpty() && unitList.stream().allMatch(Matches.unitIsLand())) {

                // Land unit
                route =
                    map.getRouteForUnit(
                        startTerritory,
                        t,
                        ProMatches.territoryCanMoveLandUnitsThrough(
                            player, data, u, startTerritory, isCombatMove, List.of()),
                        u,
                        player);
                if (route == null && startTerritory.equals(lastLandTransport.getFirst())) {
                    route =
                        map.getRouteForUnit(
                            startTerritory,
                            t,
                            ProMatches.territoryCanMoveLandUnitsThrough(
                                player,
                                data,
                                lastLandTransport.getSecond(),
                                startTerritory,
                                isCombatMove,
                                List.of()),
                            u,
                            player);
                }
            } else if (!unitList.isEmpty() && unitList.stream().allMatch(Matches.unitIsAir())) {

                // Air unit
                route =
                    map.getRouteForUnit(
                        startTerritory,
                        t,
                        ProMatches.territoryCanMoveAirUnitsAndNoAa(player, data, isCombatMove),
                        u,
                        player);
            }
            if (route == null) {
                ProLogger.warn(
                    data.getSequence().getRound()
                        + "-"
                        + data.getSequence().getStep().getName()
                        + ": route is null (could not calculate route)"
                        + startTerritory
                        + " to "
                        + t
                        + ", units="
                        + unitList);
            } else {
                moves.add(new MoveDescription(unitList, route));
            }
        }
        return moves;
    }

    public static List<MoveDescription> calculateMoveRoutesNew2(
        final GameData data,
        final MctsData mctsData,
        final GamePlayer player,
        final Territory t,
        Set<Unit> units) {

        final GameMap map = data.getMap();
        boolean isCombatMove;
        if (data.getSequence().getStep().getName().endsWith("NonCombatMove")){
            isCombatMove=false;
        } else {
            isCombatMove=true;
        }

        final var moves = new ArrayList<MoveDescription>();
        // Loop through each unit that is attacking the current territory
        Tuple<Territory, Unit> lastLandTransport = Tuple.of(null, null);
        for (final Unit u : units) {



            // Skip if unit is already in move to territory
            final Territory startTerritory = mctsData.getUnitTerritory(u);
            if (startTerritory == null || startTerritory.equals(t)) {
                continue;
            }

            // Add unit to move list
            final var unitList = new ArrayList<Unit>();
            unitList.add(u);
            if (Matches.unitIsLandTransport().test(u)) {
                lastLandTransport = Tuple.of(startTerritory, u);
            }

            // Determine route and add to move list
            Route route = null;
            if (!unitList.isEmpty() && unitList.stream().allMatch(Matches.unitIsLand())) {

                // Land unit
                route =
                    map.getRouteForUnit(
                        startTerritory,
                        t,
                        ProMatches.territoryCanMoveLandUnitsThrough(
                            player, data, u, startTerritory, isCombatMove, List.of()),
                        u,
                        player);
                if (route == null && startTerritory.equals(lastLandTransport.getFirst())) {
                    route =
                        map.getRouteForUnit(
                            startTerritory,
                            t,
                            ProMatches.territoryCanMoveLandUnitsThrough(
                                player,
                                data,
                                lastLandTransport.getSecond(),
                                startTerritory,
                                isCombatMove,
                                List.of()),
                            u,
                            player);
                }
            } else if (!unitList.isEmpty() && unitList.stream().allMatch(Matches.unitIsAir())) {

                // Air unit
                route =
                    map.getRouteForUnit(
                        startTerritory,
                        t,
                        ProMatches.territoryCanMoveAirUnitsAndNoAa(player, data, isCombatMove),
                        u,
                        player);
            }
            if (route == null) {
                ProLogger.warn(
                    data.getSequence().getRound()
                        + "-"
                        + data.getSequence().getStep().getName()
                        + ": route is null (could not calculate route)"
                        + startTerritory
                        + " to "
                        + t
                        + ", units="
                        + unitList);
            } else {
                moves.add(new MoveDescription(unitList, route));
            }
        }
        return moves;
    }


}
