package games.strategy.triplea.ai.mctsclean.nonExploringMcts;

import games.strategy.triplea.ai.mctsclean.MctsAi;
import games.strategy.triplea.ai.mctsclean.util.ForwardModel;
import games.strategy.triplea.ai.mctsclean.util.MctsData;
import games.strategy.triplea.ai.pro.logging.ProLogger;
import games.strategy.triplea.ai.weak.WeakAi;

public class NonExploringMctsAi extends AbstractNonExploringMctsAi{

  public static AbstractNonExploringMctsAi currentInstance;

  public NonExploringMctsAi(String name) {
    super(name, new MctsData());
    NonExploringMcts.runCount=0;
    ForwardModel.mctsAi=new WeakAi("");
    ProLogger.info("Starting MCTSAI class");
    currentInstance=this;
  }
}
