package games.strategy.triplea.ai.mctsclean.oepMcts;

import static games.strategy.triplea.ai.mctsclean.util.ModelTerritoryManager.canAttackSuccessfully;
import static games.strategy.triplea.ai.mctsclean.util.ModelTerritoryManager.findLandMoveOptionsSingular;
import static games.strategy.triplea.ai.mctsclean.util.ModelTerritoryManager.findLandMoveOptionsSingularSet;

import games.strategy.engine.data.Territory;
import games.strategy.engine.data.Unit;
import games.strategy.triplea.ai.AiUtils;
import games.strategy.triplea.ai.mctsclean.algorithm.NewAction;
import games.strategy.triplea.ai.mctsclean.algorithm.NewActionAdvance;
import games.strategy.triplea.ai.mctsclean.algorithm.NewActionSkip;
import games.strategy.triplea.ai.mctsclean.util.ModelMoveOptions;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public class Genome implements Comparable<Genome>{
    ArrayList<OepAction2> actions=new ArrayList<>();
    int visits=0;
    double value=0;
    Set<Unit> usedUnits=new HashSet<>();


    Genome(OepWorldModel state){
      this.actions=generateRandomActions(state);

    }

    Genome(Genome genome){

      this.actions.addAll(genome.actions);
      this.usedUnits.addAll(genome.usedUnits);

    }

    Genome(ArrayList<OepAction2> actions){
      this.actions=actions;
    }

    public ArrayList<OepAction2> generateRandomActions(OepWorldModel state){
      //implementar random actions
      ArrayList<OepAction2> actions = new ArrayList<>();
      Random rand = new Random();
      String stepName=state.data.getSequence().getStep().getName();
      if (stepName.endsWith("NonCombatMove")){
        for (Territory t2:state.alliedTerritories){
          //meter as unidades usadas na função moveoptionsingular set

          List<Set<Unit>> unitSet = findLandMoveOptionsSingularSet(state.mctsData, state.data.getSequence().getStep().getPlayerId(), state.mctsData.getMyUnitTerritories(), new ArrayList<>(), new ArrayList<>(), false, false, t2, usedUnits);
          unitSet=generateCombinations(unitSet);
          Set<Unit> units;
          if (unitSet.size()>0){
            units=unitSet.get(rand.nextInt(unitSet.size()));
          }else {
            units= new HashSet<Unit>();
          }
          actions.add(new OepAction2(t2,units));
          usedUnits.addAll(units);
        }

      } else if (stepName.endsWith("CombatMove") && !stepName.endsWith("AirborneCombatMove")) {
        Set<Unit> units;
        for (Territory t2:state.enemyTerritories){

          //meter as unidades usadas na função moveoptionsingular set

          units = findLandMoveOptionsSingular(state.mctsData, state.data.getSequence().getStep().getPlayerId(), state.mctsData.getMyUnitTerritories(), new ArrayList<>(), new ArrayList<>(), true, false, t2, usedUnits);
          if (canAttackSuccessfully(units,t2)){
            List<Set<Unit>> sets=getUnitsUpToStrengthSet(AiUtils.strength(t2.getUnits(), false, false),units);
            Set<Unit> units2=sets.get(rand.nextInt(sets.size()));
            actions.add(new OepAction2(t2, units2));
            usedUnits.addAll(units);
          } else {
            actions.add(new OepAction2(t2, new HashSet<>()));
          }

        }
      }
      return actions;
    }

  static List<Set<Unit>> getUnitsUpToStrengthSet( double maxStrength, final Collection<Unit> units) {
    List<Set<Unit>> sets = new ArrayList<Set<Unit>>();
    double str=1.5;
    final Set<Unit> unitsUpToStrength = new HashSet<>();
    Set<Unit> newSet = new HashSet<>();
    boolean full=false;
    for (final Unit u : units) {
      unitsUpToStrength.add(u);
      full=false;
      if (AiUtils.strength(unitsUpToStrength, true, false) > str*maxStrength+4) {
        full=true;
        newSet = new HashSet<>();
        newSet.addAll(unitsUpToStrength);
        sets.add(newSet);
        str+=2;
      }
    }

    if (!full){
      newSet = new HashSet<>();
      newSet.addAll(unitsUpToStrength);
      sets.add(newSet);
    }
    Collections.reverse(sets);
    return sets;
  }

  public List<Set<Unit>> generateCombinations(List<Set<Unit>> sets){
    List<Set<Unit>>  combinations = new ArrayList<>();
    int r=sets.size();
    int[] combination;
    int n= sets.size();
    while (r>0) {

      combination= new int[r];
      // initialize with lowest lexicographic combination
      for (int i = 0; i < r; i++) {
        combination[i] = i;
      }

      while (combination[r - 1] < n) {
        Set<Unit> newSet= new HashSet<>();
        for (int i:combination){
          newSet.addAll(sets.get(i));
        }
        combinations.add(newSet);

        // generate next combination in lexicographic order
        int t = r - 1;
        while (t != 0 && combination[t] == n - r + t) {
          t--;
        }
        combination[t]++;
        for (int i = t + 1; i < r; i++) {
          combination[i] = combination[i - 1] + 1;
        }
      }
      r--;
    }

    return combinations;
  }


    public void executeActions(OepWorldModel newState){
      for (OepAction2 a:actions){
        a.applyActionEffects(newState);
      }
    }

    public void randomActionForTerritory(Territory t2, OepWorldModel state, int index){
      usedUnits.removeAll(actions.get(index).units);

      Random rand = new Random();
      String stepName=state.data.getSequence().getStep().getName();

      if (stepName.endsWith("NonCombatMove")){
        //meter as unidades usadas na função moveoptionsingular set

        List<Set<Unit>> unitSet = findLandMoveOptionsSingularSet(state.mctsData, state.data.getSequence().getStep().getPlayerId(), state.mctsData.getMyUnitTerritories(), new ArrayList<>(), new ArrayList<>(), false, false, t2, usedUnits);
        unitSet=generateCombinations(unitSet);
        Set<Unit> units;
        if (unitSet.size()>0){
          units=unitSet.get(rand.nextInt(unitSet.size()));
        }else {
          units= new HashSet<Unit>();
        }
        actions.set(index,new OepAction2(t2,units));
        usedUnits.addAll(units);

      } else if (stepName.endsWith("CombatMove") && !stepName.endsWith("AirborneCombatMove")) {
        Set<Unit> units;

        //meter as unidades usadas na função moveoptionsingular set

        units = findLandMoveOptionsSingular(state.mctsData, state.data.getSequence().getStep().getPlayerId(), state.mctsData.getMyUnitTerritories(), new ArrayList<>(), new ArrayList<>(), true, false, t2, usedUnits);
        if (canAttackSuccessfully(units,t2)){
          List<Set<Unit>> sets=getUnitsUpToStrengthSet(AiUtils.strength(t2.getUnits(), false, false),units);
          Set<Unit> units2=sets.get(rand.nextInt(sets.size()));
          actions.set(index, new OepAction2(t2, units2));
          usedUnits.addAll(units2);

        }
      }



    }

    @Override
    public int compareTo(final Genome g) {
      if(value>g.value){
        return 1;
      } else if (value==g.value){
        return 0;
      } else {
        return -1;
      }

    }
}
