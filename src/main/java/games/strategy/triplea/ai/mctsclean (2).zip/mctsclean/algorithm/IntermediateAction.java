package games.strategy.triplea.ai.mctsclean.algorithm;

import games.strategy.engine.data.Territory;
import games.strategy.engine.data.Unit;
import games.strategy.triplea.ai.mctsclean.util.ForwardModel;
import games.strategy.triplea.ai.mctsclean.util.MctsData;
import games.strategy.triplea.ai.mctsclean.util.ModelTerritory;
import games.strategy.triplea.delegate.remote.IMoveDelegate;
import lombok.Getter;

@Getter
public  class IntermediateAction extends Action {
    static boolean intermediate=true;
    static long totalIntermediateActionTime=0;
    static int totalIntermediateActionExecutions=0;

    public IntermediateAction(ModelTerritory move){
        super(move);
    }

    public IntermediateAction(ModelTerritory move, boolean skip){
        super(move);
        this.skip=true;
    }

    @Override
    public void applyActionEffects(WorldModel state){
        if (!skip){
            long time=System.currentTimeMillis();
            final ModelTerritory newMove=replaceMove(state.mctsData);
            ForwardModel.doMove(state.mctsData.getData(), ForwardModel.calculateMoveRoutes(state.mctsData, state.data.getSequence().getStep().getPlayerId(), newMove), state.moveDel, true);
            totalIntermediateActionExecutions++;
            totalIntermediateActionTime+=System.currentTimeMillis()-time;
        }
        state.addExcluded(move.getTerritory());
    }



    @Override
    public String toString(){
        return "Intermediate Skip="+skip+" "+ super.toString();
    }
}