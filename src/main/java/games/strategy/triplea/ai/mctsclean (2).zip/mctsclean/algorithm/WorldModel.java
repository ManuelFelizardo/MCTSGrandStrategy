package games.strategy.triplea.ai.mctsclean.algorithm;

import static games.strategy.triplea.ai.mctsclean.util.ModelTerritoryManager.*;
import static games.strategy.triplea.delegate.Matches.isTerritoryOwnedBy;

import games.strategy.engine.data.GameData;
import games.strategy.engine.data.GamePlayer;
import games.strategy.engine.data.Territory;
import games.strategy.engine.data.Unit;
import games.strategy.engine.data.UnitType;
import games.strategy.engine.delegate.IDelegateBridge;
import games.strategy.engine.framework.GameDataUtils;
import games.strategy.triplea.ai.AiUtils;
import games.strategy.triplea.ai.mctsclean.util.*;
import games.strategy.triplea.ai.pro.logging.ProLogger;
import games.strategy.triplea.ai.weak.WeakAi;
import games.strategy.triplea.attachments.TerritoryAttachment;
import games.strategy.triplea.delegate.DelegateFinder;
import games.strategy.triplea.delegate.Matches;
import games.strategy.triplea.delegate.remote.IMoveDelegate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import org.triplea.java.collections.CollectionUtils;
import org.triplea.java.collections.IntegerMap;

public class WorldModel {

    public static long cloneDataTime=0;
    public static long worldModelCreateTime=0;


    //private final WeakAi weakAi;
    boolean isGameOver=false;
    public GameData data;
    public MctsData mctsData;
    IMoveDelegate moveDel;
    public GamePlayer player;
    private ModelTerritoryManager territoryManager;
    private Set<Territory> excluded= new HashSet<>();
    List<Territory> alliedTerritories;
    List<Territory> enemyTerritories;
    public int counter=0;
    public ArrayList<NewAction> actions;
    int actionIndex=0;
    public static int cloneDataN=0;
    public Collection<GamePlayer> victors= new ArrayList<>();

    public WorldModel(GameData data){
        this.data=data;
        this.mctsData=new MctsData();
        mctsData.initialize(data);
        this.moveDel= DelegateFinder.moveDelegate(data);
        final IDelegateBridge bridge = new MctsDummyDelegateBridge(ForwardModel.mctsAi, data.getPlayerList().getPlayerId(data.getSequence().getStep().getPlayerId().getName()), data);
        moveDel.setDelegateBridgeAndPlayer(bridge);
    }

    public void addExcluded(Territory t){
        excluded.add(t);
    }

    public void addExcluded(Set<Territory> t){
        excluded.addAll(t);
    }

    public void resetExcluded(){
        this.excluded=new HashSet<>();
    }

    //implementar
    public boolean isTerminal(){
        return isGameOver;
    }

    /*
    public void generateActions(){
        mctsData.updateData();
        territoryManager=new ModelTerritoryManager(mctsData);
        String stepName=data.getSequence().getStep().getName();
        if (stepName.endsWith("NonCombatMove")){
            territoryManager.populateDefenseOptions(new ArrayList<>());
            options=territoryManager.getDefenseOptions();
        } else if (stepName.endsWith("CombatMove") && !stepName.endsWith("AirborneCombatMove")){
            territoryManager.populateAttackOptions();
            options=territoryManager.getAttackOptions();
        }
        actions=new ArrayList<>();
        options.getTerritoryMap().keySet().removeAll(excluded);

        if (options.getTerritoryMap().size()>0){
            for(Territory t:options.getTerritoryMap().keySet()){
                actions.add(new IntermediateAction(options.getTerritoryMap().get(t)));
                actions.add(new IntermediateAction(options.getTerritoryMap().get(t), true));
                break;
            }
        } else {
            actions.add(new Action());
        }

        List<Territory> alliedTerritories= data.getMap().getTerritories().stream().filter(isTerritoryOwnedBy(data.getSequence().getStep().getPlayerId())).collect(Collectors.toList());
        List<Territory> enemyTerritories= getNeighboringEnemyTerritories(alliedTerritories,data.getSequence().getStep().getPlayerId(),data);
        Set<Unit> units = findLandMoveOptionsSingular(mctsData,data.getSequence().getStep().getPlayerId(),mctsData.getMyUnitTerritories(),new ArrayList<>(),new ArrayList<>(),true, false,enemyTerritories.get(0));
        if (canAttackSuccessfully(units,enemyTerritories.get(0))){
            throw new NullPointerException(enemyTerritories.get(0)+"            ;             "+units.toString());
        }

    }
    */

    public void doMoveWeakAi(WeakAi ai){
        boolean nonCombat=data.getSequence().getStep().getName().endsWith("NonCombatMove") ? true : false;
        //final IDelegateBridge bridge =new MctsDummyDelegateBridge(ForwardModel.mctsAi, data.getPlayerList().getPlayerId(data.getSequence().getStep().getPlayerId().getName()), data);
        //moveDel.setDelegateBridgeAndPlayer(bridge);
        ai.moveSimple(nonCombat,moveDel,data,data.getSequence().getStep().getPlayerId());
    }

    public void setEnemyTerritories(List<Territory> enemyTerritories){
        this.enemyTerritories=enemyTerritories;
    }

    public void setAlliedTerritories(List<Territory> alliedTerritories){
        this.alliedTerritories=alliedTerritories;
    }

    public void generateAlliedTerritories(){
        alliedTerritories= data.getMap().getTerritories().stream().filter(isTerritoryOwnedBy(data.getSequence().getStep().getPlayerId())).collect(Collectors.toList());
        sortTerritories();
    }

    public void generateEnemyTerritories(){
        enemyTerritories=getNeighboringEnemyTerritories(alliedTerritories,data.getSequence().getStep().getPlayerId(),data);
    }

    public int getActionsSize(){

        int actionSize=0;
        String stepName=data.getSequence().getStep().getName();
        if (stepName.endsWith("NonCombatMove")){
            Territory t;
            for (Territory t2:alliedTerritories){
                t=(Territory) data.getUnitHolder(t2.getName(),"T");
                if (!excluded.contains(t) ) {
                    actionSize++;
                }
            }

        } else if (stepName.endsWith("CombatMove") && !stepName.endsWith("AirborneCombatMove")) {
            Set<Unit> units;
            Territory t;
            for (Territory t2:enemyTerritories){
                t=(Territory) data.getUnitHolder(t2.getName(),"T");
                if (!excluded.contains(t)) {
                    units = findLandMoveOptionsSingular(mctsData, data.getSequence().getStep().getPlayerId(), mctsData.getMyUnitTerritories(), new ArrayList<>(), new ArrayList<>(), true, false, t);
                    if (canAttackSuccessfully(units,t)){
                        actionSize++;
                    }

                }
            }
        }
        return actionSize;
    }

    public void sortTerritories(){
        List<Territory> neighboringEnemy= new ArrayList<>();

        for (final Territory t : alliedTerritories) {
            if (!data.getMap().getNeighbors(t, Matches.isTerritoryEnemyAndNotUnownedWaterOrImpassableOrRestricted(data.getSequence().getStep().getPlayerId(),data)).isEmpty()){
                neighboringEnemy.add(t);
            }
        }
        //List<Territory> neighboringEnemy=CollectionUtils.getMatches(alliedTerritories,match);
        alliedTerritories.sort(
            (o1, o2) -> {
                // -1 means o1 goes first. 1 means o2 goes first. zero means they are equal.
                if (Objects.equals(o1, o2)) {
                    return 0;
                }
                if (o1 == null) {
                    return 1;
                }
                if (o2 == null) {
                    return -1;
                }
                final TerritoryAttachment ta1 = TerritoryAttachment.get(o1);
                final TerritoryAttachment ta2 = TerritoryAttachment.get(o2);
                if (ta1 == null && ta2 == null) {
                    return 0;
                }
                if (ta1 == null) {
                    return 1;
                }
                if (ta2 == null) {
                    return -1;
                }
                // take capitols first if we can
                if (ta1.isCapital() && !ta2.isCapital()) {
                    return -1;
                }
                if (!ta1.isCapital() && ta2.isCapital()) {
                    return 1;
                }
                if (neighboringEnemy.contains(o1)&&!neighboringEnemy.contains(o2)) {
                    return -1;
                }
                if (!neighboringEnemy.contains(o1)&&neighboringEnemy.contains(o2)) {
                    return 1;
                }
                if (!ta1.isCapital() && ta2.isCapital()) {
                    return 1;
                }
                // next take territories with largest PU value
                return ta2.getProduction() - ta1.getProduction();
            });
    }

    public void generateActions(){
        mctsData.updateData();
        actions=new ArrayList<>();

        String stepName=data.getSequence().getStep().getName();
        if (stepName.endsWith("NonCombatMove")){
            Territory t;
            for (Territory t2:alliedTerritories){
                t=(Territory) data.getUnitHolder(t2.getName(),"T");
                if (!excluded.contains(t) ) {
                    List<Set<Unit>> unitSet = findLandMoveOptionsSingularSet(mctsData, data.getSequence().getStep().getPlayerId(), mctsData.getMyUnitTerritories(), new ArrayList<>(), new ArrayList<>(), false, false, t);
                    unitSet=generateCombinations(unitSet);
                    actions.add(new NewActionSkip(t, new HashSet()));
                    for(Set<Unit> units:unitSet){
                        actions.add(new NewAction(t,units));
                    }
                    return;
                }
            }
            actions.add(new NewActionAdvance());

        } else if (stepName.endsWith("CombatMove") && !stepName.endsWith("AirborneCombatMove")) {
            Set<Unit> units;
            Territory t;
            for (Territory t2:enemyTerritories){
                t=(Territory) data.getUnitHolder(t2.getName(),"T");
                if (!excluded.contains(t)) {
                    units = findLandMoveOptionsSingular(mctsData, data.getSequence().getStep().getPlayerId(), mctsData.getMyUnitTerritories(), new ArrayList<>(), new ArrayList<>(), true, false, t);
                    if (canAttackSuccessfully(units,t)){
                        List<Set<Unit>> sets=getUnitsUpToStrengthSet(AiUtils.strength(t.getUnits(), false, false),units);
                        actions.add(new NewActionSkip(t, new HashSet()));
                        for (Set<Unit> unitSet:sets){
                            actions.add(new NewAction(t,unitSet));
                        }
                        return;
                    } else {
                        excluded.add(t);
                        continue;
                    }

                }
            }
            actions.add(new NewActionAdvance());
        }

    }

    public List<Set<Unit>> generateCombinations(List<Set<Unit>> sets){
        List<Set<Unit>>  combinations = new ArrayList<>();
        int r=sets.size();
        int[] combination;
        int n= sets.size();
        while (r>0) {

            combination= new int[r];
            // initialize with lowest lexicographic combination
            for (int i = 0; i < r; i++) {
                combination[i] = i;
            }

            while (combination[r - 1] < n) {
                Set<Unit> newSet= new HashSet<>();
                for (int i:combination){
                    newSet.addAll(sets.get(i));
                }
                combinations.add(newSet);

                // generate next combination in lexicographic order
                int t = r - 1;
                while (t != 0 && combination[t] == n - r + t) {
                    t--;
                }
                combination[t]++;
                for (int i = t + 1; i < r; i++) {
                    combination[i] = combination[i - 1] + 1;
                }
            }
            r--;
        }

        return combinations;
    }

    /*
    public void generateActions(){
        mctsData.updateData();
        actions=new ArrayList<>();

        String stepName=data.getSequence().getStep().getName();
        if (stepName.endsWith("NonCombatMove")){
            Set<Unit> units;
            for (Territory t:alliedTerritories){
                if (!excluded.contains(t)) {
                    units = findLandMoveOptionsSingular(mctsData, data.getSequence().getStep().getPlayerId(), mctsData.getMyUnitTerritories(), new ArrayList<>(), new ArrayList<>(), false, false, t);
                    actions.add(new NewAction(t,units));
                    actions.add(new NewActionSkip(t, new HashSet()));
                    return;
                }
            }
            actions.add(new NewActionAdvance());

        } else if (stepName.endsWith("CombatMove") && !stepName.endsWith("AirborneCombatMove")) {
            Set<Unit> units;
            for (Territory t:enemyTerritories){
                if (!excluded.contains(t)) {
                    units = findLandMoveOptionsSingular(mctsData, data.getSequence().getStep().getPlayerId(), mctsData.getMyUnitTerritories(), new ArrayList<>(), new ArrayList<>(), true, false, t);
                    if (canAttackSuccessfully(units,t)){
                        actions.add(new NewAction(t,getUnitsUpToStrength(AiUtils.strength(t.getUnits(), false, false),units)));
                        actions.add(new NewActionSkip(t, new HashSet()));
                        return;
                    } else {
                        excluded.add(t);
                        continue;
                    }

                }
            }
            actions.add(new NewActionAdvance());
        }

    }

     */

    public void permutations(MctsData mctsData, Territory t, List<Unit> units){
        HashMap<UnitType,Set<Unit>> map= new HashMap<>();
        for (Unit u:units){
            if (map.containsKey(u.getType())){
                map.get(u.getType()).add(u);
            } else {
                Set<Unit> set=new HashSet<Unit>();
                set.add(u);
                map.put(u.getType(),set);
            }
        }

        for (UnitType type:map.keySet()){

        }


    }

    public void iterateNext(List<Set<Unit>> permutations,HashMap<UnitType,Set<Unit>> map,int index){
        for (UnitType type:map.keySet()){

        }
    }

    static Set<Unit> getUnitsUpToStrength( double maxStrength, final Collection<Unit> units) {
        maxStrength = (4 * maxStrength) + 4;
        final Set<Unit> unitsUpToStrength = new HashSet<>();
        for (final Unit u : units) {
            unitsUpToStrength.add(u);
            if (AiUtils.strength(unitsUpToStrength, true, false) > maxStrength) {
                return unitsUpToStrength;
            }
        }
        return unitsUpToStrength;
    }

    static List<Set<Unit>> getUnitsUpToStrengthSet( double maxStrength, final Collection<Unit> units) {
        List<Set<Unit>> sets = new ArrayList<Set<Unit>>();
        double str=1.2;
        final Set<Unit> unitsUpToStrength = new HashSet<>();
        Set<Unit> newSet = new HashSet<>();
        boolean full=false;
        for (final Unit u : units) {
            unitsUpToStrength.add(u);
            full=false;
            if (AiUtils.strength(unitsUpToStrength, true, false) > str*maxStrength+4) {
                full=true;
                newSet = new HashSet<>();
                newSet.addAll(unitsUpToStrength);
                sets.add(newSet);
                str+=0.3;
            }
        }

        if (!full){
            newSet = new HashSet<>();
            newSet.addAll(unitsUpToStrength);
            sets.add(newSet);
        }
        Collections.reverse(sets);
        return sets;
    }


    //implementar
    public ArrayList<NewAction> getExecutableActions(){
        return actions;
    }

    public NewAction getNextAction(){
        if (actionIndex<actions.size()){
            return actions.get(actionIndex++);
        }
        else {
            return null;
        }
    }


    //implementar
    public WorldModel generateChildWorldModel(){
        GameData dataCopy;
        long time=System.currentTimeMillis();
        dataCopy = GameDataUtils.cloneGameDataWithoutHistoryFast(data, true);
        cloneDataTime+=System.currentTimeMillis()-time;
        cloneDataN++;
        time=System.currentTimeMillis();
        WorldModel newModel =new WorldModel(dataCopy);
        worldModelCreateTime=System.currentTimeMillis()-time;
        newModel.addExcluded(excluded);
        newModel.setAlliedTerritories(alliedTerritories);
        newModel.setEnemyTerritories(enemyTerritories);
        return newModel;
    }

    public double getWorldHeuristic(GamePlayer player){
        int unitN=0;
        IntegerMap<UnitType> map= data.getPlayerList().getPlayerId(player.getName()).getUnitCollection().getUnitsByType();
        /*
        for (UnitType t:map.keySet()){
            t.getClass().getAnnotations()
            unitN=data.getSequence().getStep().getPlayerId().getUnitCollection().getUnitsByType()

        }
         */
        unitN=data.getSequence().getStep().getPlayerId().getUnitCollection().size();
        return unitN;
    }


}