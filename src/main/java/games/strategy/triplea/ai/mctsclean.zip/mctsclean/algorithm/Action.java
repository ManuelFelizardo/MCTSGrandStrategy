package games.strategy.triplea.ai.mctsclean.algorithm;
import static games.strategy.triplea.ai.mctsclean.util.ModelTerritoryManager.getNeighboringEnemyTerritories;
import static games.strategy.triplea.delegate.Matches.isTerritoryOwnedBy;

import games.strategy.engine.data.Change;
import games.strategy.engine.data.GameData;
import games.strategy.engine.data.GamePlayer;
import games.strategy.engine.data.GameStep;
import games.strategy.engine.data.MoveDescription;
import games.strategy.engine.data.Resource;
import games.strategy.engine.data.Territory;
import games.strategy.engine.data.Unit;
import games.strategy.engine.data.changefactory.ChangeFactory;
import games.strategy.engine.delegate.IDelegate;
import games.strategy.engine.delegate.IDelegateBridge;
import games.strategy.triplea.Constants;
import games.strategy.triplea.ai.fast.FastOddsEstimator;
import games.strategy.triplea.ai.mctsclean.oepMcts.OepWorldModel;
import games.strategy.triplea.ai.mctsclean.util.ForwardModel;
import games.strategy.triplea.ai.mctsclean.util.MctsData;
import games.strategy.triplea.ai.mctsclean.util.ModelTerritory;
import games.strategy.triplea.ai.mctstest.MctsAi;
import games.strategy.triplea.ai.mctstest.forwardmodel.MctsDummyDelegateBridge;
import games.strategy.triplea.ai.pro.ProData;
import games.strategy.triplea.ai.pro.data.ProBattleResult;
import games.strategy.triplea.ai.pro.logging.ProLogger;
import games.strategy.triplea.ai.pro.simulate.ProSimulateTurnUtils;
import games.strategy.triplea.ai.pro.util.ProOddsCalculator;
import games.strategy.triplea.delegate.DelegateFinder;
import games.strategy.triplea.delegate.EndRoundDelegate;
import games.strategy.triplea.delegate.Matches;
import games.strategy.triplea.delegate.battle.BattleDelegate;
import games.strategy.triplea.delegate.battle.BattleTracker;
import games.strategy.triplea.delegate.battle.IBattle;
import games.strategy.triplea.delegate.remote.IAbstractPlaceDelegate;
import games.strategy.triplea.delegate.remote.IMoveDelegate;
import games.strategy.triplea.delegate.remote.IPurchaseDelegate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import lombok.Getter;
import org.triplea.java.collections.CollectionUtils;
import games.strategy.triplea.ai.weak.WeakAi;

@Getter
public  class Action {

  final ModelTerritory move;
  static boolean intermediate = false;
  static long totalActionTime=0;
  static int totalActionExecutions=0;

  static long battleTime=0;
  static long placeTime=0;
  static long bidTime=0;
  static long purchaseTime=0;
  static int battleExecutions=0;
  static int placeExecutions=0;
  static int bidExecutions=0;
  static int purchaseExecutions=0;

  public boolean skip=false;


  //implementar
  public Action() { this.move=null;
  }
  public Action(ModelTerritory move) {
    this.move = move;
  }

  public void applyActionEffects(WorldModel state) {
    long time=System.currentTimeMillis(); totalActionExecutions++;
    advance(state);
    totalActionTime+=System.currentTimeMillis()-time;
  }

  public void applyActionEffects2(WorldModel state) {
    long time=System.currentTimeMillis();
    final ModelTerritory newMove=replaceMove(state.mctsData);
    ForwardModel.doMove(state.mctsData.getData(), ForwardModel.calculateMoveRoutes(state.mctsData, state.data.getSequence().getStep().getPlayerId(), newMove), state.moveDel, true);
    totalActionExecutions++;
    advance(state);
    totalActionTime+=System.currentTimeMillis()-time;
  }

  public Action replace(MctsData data){
    ModelTerritory newT= new ModelTerritory((Territory) data.getData().getUnitHolder(move.getTerritory().getName(),"T"), data);
    for (Unit u: move.getUnits()){
      newT.addUnit(data.getData().getUnits().get(u.getId()));
    }
    return new Action(newT);
  }


  public ModelTerritory replaceMove(MctsData data){
    ModelTerritory newT= new ModelTerritory((Territory) data.getData().getUnitHolder(move.getTerritory().getName(),"T"), data);
    for (Unit u: move.getUnits()){
      newT.addUnit(data.getData().getUnits().get(u.getId()));
    }
    return newT;
  }

  public static GameStep getNextStep(WorldModel state){
    if (state.data.getSequence().getStepIndex()+1>=state.data.getSequence().size()){
      return state.data.getSequence().getStep(state.data.getSequence().getStepIndex()+1-state.data.getSequence().size());
    }
    return state.data.getSequence().getStep(state.data.getSequence().getStepIndex()+1);
  }

  public static GameStep getNextStep(OepWorldModel state){
    if (state.data.getSequence().getStepIndex()+1>=state.data.getSequence().size()){
      return state.data.getSequence().getStep(state.data.getSequence().getStepIndex()+1-state.data.getSequence().size());
    }
    return state.data.getSequence().getStep(state.data.getSequence().getStepIndex()+1);
  }


  public static void advance(WorldModel state){
    boolean nonCombat = false;
    if (state.data.getSequence().getStep().getName().endsWith("NonCombatMove")){
      state.data.getSequence().getStep().getDelegate().start();
      state.data.getSequence().getStep().getDelegate().end();
      nonCombat=true;
    }
    //state.data.getSequence().getStep().getDelegate().end();
    GameStep gameStep =getNextStep(state);
    state.data.getSequence().next();

    long time;

    while(!gameStep.getName().endsWith("NonCombatMove") && !gameStep.getName().endsWith("CombatMove")){


      //ProLogger.info("-------------------------------------->>  stage " + state.data.getSequence().getStep().getName());
      if (gameStep.getName().endsWith("Battle")) {

        final BattleDelegate battleDelegate = DelegateFinder.battleDelegate(state.data);
        final IDelegateBridge bridge2 = new MctsDummyDelegateBridge(MctsAi.currentInstance, state.data.getSequence().getStep().getPlayerId(), state.data);
        battleDelegate.setDelegateBridgeAndPlayer(bridge2);

        battleExecutions++;
        time=System.currentTimeMillis();
        simulateBattles(state.data,state.data.getSequence().getStep().getPlayerId(), state.moveDel.getBridge());
        battleTime+=System.currentTimeMillis()-time;
        gameStep = getNextStep(state);
        state.data.getSequence().next();
        continue;
      }
      if (nonCombat) {
        final IDelegateBridge bridge1 = new MctsDummyDelegateBridge(MctsAi.currentInstance, state.data.getSequence().getStep().getPlayerId(), state.data);
        state.data.getSequence().getStep().getDelegate().setDelegateBridgeAndPlayer(bridge1);
        state.data.getSequence().getStep().getDelegate().end();
      }

      gameStep = getNextStep(state);
      state.data.getSequence().next();
    }
    final IDelegateBridge bridge = new games.strategy.triplea.ai.mctsclean.util.MctsDummyDelegateBridge(ForwardModel.mctsAi, state.data.getPlayerList().getPlayerId(state.data.getSequence().getStep().getPlayerId().getName()), state.data);
    state.moveDel.setDelegateBridgeAndPlayer(bridge);
    if(state.data.getSequence().getStepIndex()==6){

      final EndRoundDelegateMcts delegate = new EndRoundDelegateMcts();
      //(EndRoundDelegateMcts) state.data.getDelegate("endRound");
      delegate.setDelegateBridgeAndPlayer(state.moveDel.getBridge());
      delegate.start();
      state.isGameOver=delegate.gameOver;
      state.victors=delegate.getWinners();
      //throw new NullPointerException(state.data.getSequence().getStep().getName());
    }
    state.resetExcluded();
    state.generateAlliedTerritories();
    state.generateEnemyTerritories();

  }

  public static void advancePlayout(WorldModel state){
    boolean nonCombat = false;
    if (state.data.getSequence().getStep().getName().endsWith("NonCombatMove")){
      state.data.getSequence().getStep().getDelegate().start();
      state.data.getSequence().getStep().getDelegate().end();
      nonCombat=true;
    }
    //state.data.getSequence().getStep().getDelegate().end();
    GameStep gameStep =getNextStep(state);
    state.data.getSequence().next();

    long time;

    while(!gameStep.getName().endsWith("NonCombatMove") && !gameStep.getName().endsWith("CombatMove")){


      //ProLogger.info("-------------------------------------->>  stage " + state.data.getSequence().getStep().getName());
      if (gameStep.getName().endsWith("Battle")) {

        final BattleDelegate battleDelegate = DelegateFinder.battleDelegate(state.data);
        final IDelegateBridge bridge2 = new MctsDummyDelegateBridge(MctsAi.currentInstance, state.data.getSequence().getStep().getPlayerId(), state.data);
        battleDelegate.setDelegateBridgeAndPlayer(bridge2);

        battleExecutions++;
        time=System.currentTimeMillis();
        simulateBattles(state.data,state.data.getSequence().getStep().getPlayerId(), state.moveDel.getBridge());
        battleTime+=System.currentTimeMillis()-time;
        gameStep = getNextStep(state);
        state.data.getSequence().next();
        continue;
      }
      if (nonCombat) {
        final IDelegateBridge bridge1 = new MctsDummyDelegateBridge(MctsAi.currentInstance, state.data.getSequence().getStep().getPlayerId(), state.data);
        state.data.getSequence().getStep().getDelegate().setDelegateBridgeAndPlayer(bridge1);
        state.data.getSequence().getStep().getDelegate().end();
      }

      gameStep = getNextStep(state);
      state.data.getSequence().next();
    }

    final IDelegateBridge bridge = new games.strategy.triplea.ai.mctsclean.util.MctsDummyDelegateBridge(ForwardModel.mctsAi, state.data.getSequence().getStep().getPlayerId(), state.data);
    state.moveDel.setDelegateBridgeAndPlayer(bridge);
    if(state.data.getSequence().getStepIndex()==6){

      final EndRoundDelegateMcts delegate = new EndRoundDelegateMcts();
      //(EndRoundDelegateMcts) state.data.getDelegate("endRound");
      delegate.setDelegateBridgeAndPlayer(state.moveDel.getBridge());
      delegate.start();
      state.isGameOver=delegate.gameOver;
      state.victors=delegate.getWinners();
    }

  }

  public void advance2(WorldModel state){
    WeakAi weakAi= new WeakAi("test");
    GameStep gameStep =getNextStep(state);
    state.data.getSequence().next();

    long time;

    while(!gameStep.getName().endsWith("NonCombatMove") && !gameStep.getName().endsWith("CombatMove")){
      //ProLogger.info("-------------------------------------->>  stage " + state.data.getSequence().getStep().getName());
      if (gameStep.getName().endsWith("Battle")) {
        battleExecutions++;
        time=System.currentTimeMillis();
        simulateBattles(state.data,state.data.getSequence().getStep().getPlayerId(), state.moveDel.getBridge());
        battleTime+=System.currentTimeMillis()-time;
      } else if (gameStep.getName().endsWith("Place")){
        //ProLogger.info("did place");
        time=System.currentTimeMillis();
        placeExecutions++;
        IAbstractPlaceDelegate placeDel = (IAbstractPlaceDelegate) state.data.getDelegate("place");
        final IDelegateBridge bridge = new MctsDummyDelegateBridge(MctsAi.currentInstance, state.data.getSequence().getStep().getPlayerId(), state.data);
        placeDel.setDelegateBridgeAndPlayer(bridge);
        if (placeDel == null) {
          throw new IllegalStateException("place delegate not found");
        }
        time=System.currentTimeMillis();
        weakAi.place(gameStep.getName().contains("Bid"), placeDel,state.data,state.data.getSequence().getStep().getPlayerId());
        placeTime+=System.currentTimeMillis()-time;

      } else if (gameStep.getName().endsWith("Bid")) {

        //ProLogger.info("did bid");
        bidExecutions++;

        final IPurchaseDelegate purchaseDel2 = (IPurchaseDelegate) state.data.getDelegate("purchase");
        final IDelegateBridge bridge = new MctsDummyDelegateBridge(MctsAi.currentInstance, state.data.getSequence().getStep().getPlayerId(), state.data);
        purchaseDel2.setDelegateBridgeAndPlayer(bridge);
        if (purchaseDel2 == null) {
          throw new IllegalStateException("place delegate not found");
        }
        String propertyName = state.data.getSequence().getStep().getPlayerId().getName() + " bid";
        int bidAmount = state.data.getProperties().get(propertyName, 0);
        if (state.data.getSequence().getStep().getPlayerId()==null){
          throw new NullPointerException();
        }
        time=System.currentTimeMillis();
        weakAi.purchase(true,bidAmount ,purchaseDel2,state.data,state.data.getSequence().getStep().getPlayerId());
        bidTime+=System.currentTimeMillis()-time;
      } else if (gameStep.getName().endsWith("Purchase")){

        //ProLogger.info("did purchase");
        purchaseExecutions++;
        time=System.currentTimeMillis();
        final IPurchaseDelegate purchaseDel = (IPurchaseDelegate) state.data.getDelegate("purchase");
        if (purchaseDel == null) {
          throw new IllegalStateException("place delegate not found");
        }
        purchaseDel.setDelegateBridgeAndPlayer(new MctsDummyDelegateBridge(games.strategy.triplea.ai.mctstest.forwardmodel.ForwardModel.mctsAi, state.data.getPlayerList().getPlayerId(state.data.getSequence().getStep().getPlayerId().getName()), state.data));
        Resource pus = state.data.getResourceList().getResource(Constants.PUS);
        int leftToSpend = state.data.getSequence().getStep().getPlayerId().getResources().getQuantity(pus);
        time=System.currentTimeMillis();
        weakAi.purchase(false,leftToSpend ,purchaseDel,state.data,state.data.getSequence().getStep().getPlayerId());
        purchaseTime+=System.currentTimeMillis()-time;

      }
      gameStep = getNextStep(state);
      state.data.getSequence().next();
    }
  }

  public static void simulateBattles(
      final GameData data,
      final GamePlayer player,
      final IDelegateBridge delegateBridge) {

    ProData proData= new ProData();
    proData.hiddenInitialize(data, player, true);
    //ProLogger.info("Starting battle simulation phase");
    final ProOddsCalculator calc= new ProOddsCalculator(new FastOddsEstimator(proData));

    final BattleDelegate battleDelegate = DelegateFinder.battleDelegate(data);
    final Map<IBattle.BattleType, Collection<Territory>> battleTerritories =
        battleDelegate.getBattles().getBattles();
    for (final Map.Entry<IBattle.BattleType, Collection<Territory>> entry : battleTerritories.entrySet()) {
      for (final Territory t : entry.getValue()) {
        final IBattle battle =
            battleDelegate
                .getBattleTracker()
                .getPendingBattle(t, entry.getKey().isBombingRun(), entry.getKey());
        final Collection<Unit> attackers = new ArrayList<>(battle.getAttackingUnits());
        if (attackers.size()==0){
          throw new NullPointerException("no attackers --- "+attackers+"    ");
        }
        attackers.retainAll(t.getUnits());
        if (attackers.size()==0){
          //throw new NullPointerException("no attackers --- "+attackers+"    ");
        }
        final Collection<Unit> defenders = new ArrayList<>(battle.getDefendingUnits());
        defenders.retainAll(t.getUnits());
        final Collection<Unit> bombardingUnits = battle.getBombardingUnits();
       // ProLogger.debug("---" + t);
        //ProLogger.debug("attackers=" + attackers);
        //ProLogger.debug("defenders=" + defenders);
        //ProLogger.debug("bombardingUnits=" + bombardingUnits);

        final ProBattleResult result =
            calc.callBattleCalc(proData, t, attackers, defenders, bombardingUnits);
        final Collection<Unit> remainingAttackers = result.getAverageAttackersRemaining();
        final Collection<Unit> remainingDefenders = result.getAverageDefendersRemaining();
        //ProLogger.debug("remainingAttackers=" + remainingAttackers);
        //ProLogger.debug("remainingDefenders=" + remainingDefenders);

        // Make updates to data
        final List<Unit> attackersToRemove = new ArrayList<>(attackers);
        attackersToRemove.removeAll(remainingAttackers);
        if (remainingAttackers.size()==0 && remainingDefenders.size()!=0){
          //throw new NullPointerException("lost combat --- "+attackers+"    "+defenders);
        }
        final List<Unit> defendersToRemove =
            CollectionUtils.getMatches(defenders, Matches.unitIsInfrastructure().negate());
        defendersToRemove.removeAll(remainingDefenders);
        final List<Unit> infrastructureToChangeOwner =
            CollectionUtils.getMatches(defenders, Matches.unitIsInfrastructure());
        //ProLogger.debug("attackersToRemove=" + attackersToRemove);
        //ProLogger.debug("defendersToRemove=" + defendersToRemove);
        //ProLogger.debug("infrastructureToChangeOwner=" + infrastructureToChangeOwner);
        final Change attackersKilledChange = ChangeFactory.removeUnits(t, attackersToRemove);
        delegateBridge.addChange(attackersKilledChange);
        final Change defendersKilledChange = ChangeFactory.removeUnits(t, defendersToRemove);
        delegateBridge.addChange(defendersKilledChange);
        if (!(remainingAttackers.size()==0 && remainingDefenders.size()!=0)){
          BattleTracker.captureOrDestroyUnits(t, player, player, delegateBridge, null);
          if (!ProSimulateTurnUtils.checkIfCapturedTerritoryIsAlliedCapital(t, data, player, delegateBridge)) {
            delegateBridge.addChange(ChangeFactory.changeOwner(t, player));
          }
          battleDelegate.getBattleTracker().getConquered().add(t);

        }
        battleDelegate.getBattleTracker().removeBattle(battle, data);
        final Territory updatedTerritory = data.getMap().getTerritory(t.getName());
        /*ProLogger.debug(
            "after changes owner="
                + updatedTerritory.getOwner()
                + ", units="
                + updatedTerritory.getUnits());

         */
      }
    }
  }

  @Override
  public String toString() {
    return "action "; //+move.toString();
  }
}