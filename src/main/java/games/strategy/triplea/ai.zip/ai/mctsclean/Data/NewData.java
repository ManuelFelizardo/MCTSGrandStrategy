//package games.strategy.triplea.ai.mctsclean.Data;
//
//import com.google.common.annotations.VisibleForTesting;
//import com.google.common.base.MoreObjects;
//import games.strategy.engine.data.AllianceTracker;
//import games.strategy.engine.data.GameMap;
//import games.strategy.engine.data.GameSequence;
//import games.strategy.engine.data.PlayerList;
//import games.strategy.engine.data.ResourceList;
//import games.strategy.engine.data.UnitHolder;
//import games.strategy.engine.data.UnitTypeList;
//import games.strategy.engine.data.UnitsList;
//import games.strategy.engine.data.events.GameDataChangeListener;
//import games.strategy.engine.data.events.TerritoryListener;
//import games.strategy.engine.data.properties.GameProperties;
//import games.strategy.engine.delegate.IDelegate;
//import games.strategy.engine.framework.GameDataManager;
//import games.strategy.engine.framework.IGameLoader;
//import games.strategy.engine.framework.message.PlayerListing;
//import games.strategy.engine.history.History;
//import games.strategy.triplea.TripleA;
//import java.io.IOException;
//import java.io.ObjectInputStream;
//import java.io.Serializable;
//import java.util.ArrayList;
//import java.util.Collection;
//import java.util.HashMap;
//import java.util.HashSet;
//import java.util.Iterator;
//import java.util.List;
//import java.util.Map;
//import java.util.Optional;
//import java.util.Set;
//import java.util.concurrent.CopyOnWriteArrayList;
//import java.util.concurrent.locks.ReadWriteLock;
//import java.util.concurrent.locks.ReentrantReadWriteLock;
//import javax.swing.SwingUtilities;
//import org.triplea.io.IoUtils;
//import org.triplea.util.Tuple;
//import org.triplea.util.Version;
///***
///**
// * Central place to find all the information for a running game.
// *
// * <p>Using this object you can find the territories, connections, production rules, unit types...
// *
// * <p>Threading. The game data, and all parts of the game data (such as Territories, Players,
// * Units...) are protected by a read/write lock. If you are reading the game data, you should read
// * while you have the read lock as below.
// *
// * <p><code>
// * data.acquireReadLock();
// * try
// * {
// *   //read data here
// * }
// * finally
// * {
// *   data.releaseReadLock();
// * }
// * </code> The exception is delegates within a start(), end() or any method called from an
// * IRemotePlayer through the delegates remote interface. The delegate will have a read lock for the
// * duration of those methods.
// *
// * <p>Non engine code must NOT acquire the games writeLock(). All changes to game Data must be made
// * through a DelegateBridge or through a History object.
// */
//public class NewData implements Serializable {
//  private static final long serialVersionUID = -2612710634080125728L;
//
//  private int diceSides;
//  private transient List<TerritoryListener> territoryListeners = new CopyOnWriteArrayList<>();
//  private transient List<GameDataChangeListener> dataChangeListeners = new CopyOnWriteArrayList<>();
//  private transient Map<String, IDelegate> delegates = new HashMap<>();
//  private final AllianceTracker alliances = new AllianceTracker();
//  private final GameMap map = new GameMap(this);
//  private final PlayerList playerList = new PlayerList(this);
//  private final ResourceList resourceList = new ResourceList(this);
//  private final GameSequence sequence = new GameSequence(this);
//  private final UnitTypeList unitTypeList = new UnitTypeList(this);
//  private final GameProperties properties = new GameProperties(this);
//  private final UnitsList unitsList = new UnitsList();
//
//
//
//
//  /**
//   * Return the GameMap. The game map allows you to list the territories in the game, and to see
//   * which territory is connected to which.
//   *
//   * @return the map for this game.
//   */
//  public GameMap getMap() {
//    return map;
//  }
//
//  /** Returns a collection of all units in the game. */
//  public UnitsList getUnits() {
//    return unitsList;
//  }
//
//  /** Returns list of Players in the game. */
//  public PlayerList getPlayerList() {
//    return playerList;
//  }
//
//  /** Returns list of resources available in the game. */
//  public ResourceList getResourceList() {
//    return resourceList;
//  }
//
//  /** Returns the Alliance Tracker for the game. */
//  public AllianceTracker getAllianceTracker() {
//    return alliances;
//  }
//
//
//  public GameSequence getSequence() {
//    return sequence;
//  }
//
//  public UnitTypeList getUnitTypeList() {
//    return unitTypeList;
//  }
//
//  public Collection<IDelegate> getDelegates() {
//    return delegates.values();
//  }
//
//  public void addDelegate(final IDelegate delegate) {
//    delegates.put(delegate.getName(), delegate);
//  }
//
//  public IDelegate getDelegate(final String name) {
//    return delegates.get(name);
//  }
//
//  public UnitHolder getUnitHolder(final String name, final String type) {
//    switch (type) {
//      case UnitHolder.PLAYER:
//        return playerList.getPlayerId(name);
//      case UnitHolder.TERRITORY:
//        return map.getTerritory(name);
//      default:
//        throw new IllegalStateException("Invalid type:" + type);
//    }
//  }
//
//  public GameProperties getProperties() {
//    return properties;
//  }
//
//
//
//  @Override
//  public String toString() {
//    return MoreObjects.toStringHelper(this)
//        .add("playerList", playerList)
//        .toString();
//  }
//
//  /**
//   * Returns the current game round (with locking). TODO: the locking here is probably not
//   * necessary! If the current round is updated immediately after we return from this method, then
//   * the lock will have been to no effect anyways!
//   */
//  public int getCurrentRound() {
//    return getSequence().getRound();
//  }
//
//}
