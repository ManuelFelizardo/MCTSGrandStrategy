package games.strategy.triplea.ai.mctstest.algorithm;

import games.strategy.engine.data.Territory;
import games.strategy.engine.data.Unit;
import games.strategy.engine.data.GameData;

import java.util.HashMap;
import java.util.Map;

public class ActionWrapper {

    public Map<Unit, Territory> actions;

    public ActionWrapper(){
        this.actions= new HashMap<Unit, Territory>();
    }

    public ActionWrapper(Map<Unit, Territory> actionsMap){
        this.actions= new HashMap<Unit, Territory>(actionsMap);
    }

    public void addMovement(Unit unit, Territory territory){
        actions.put(unit,territory);
    }

    @Override
    public ActionWrapper clone(){
        return new ActionWrapper(this.actions);
    }

    public ActionWrapper replaceUnits(GameData data){
        ActionWrapper newWrapper=new ActionWrapper();
        for (Unit a:actions.keySet()){

            newWrapper.addMovement(data.getUnits().get(a.getId()),(Territory) data.getUnitHolder(actions.get(a).getName(),"T"));
        }
        return newWrapper;
    }

    public ActionWrapper replaceUnit(GameData data, Unit u){
        ActionWrapper newWrapper=new ActionWrapper();
        for (Unit a:actions.keySet()){

            newWrapper.addMovement(data.getUnits().get(a.getId()),(Territory) data.getUnitHolder(actions.get(a).getName(),"T"));
        }
        return newWrapper;
    }

}
