package games.strategy.triplea.ai.mctstest.OEP;

import games.strategy.triplea.ai.mctstest.forwardmodel.ForwardModel;
import games.strategy.triplea.ai.mctstest.forwardmodel.MctsData;
import games.strategy.triplea.ai.pro.logging.ProLogger;
import games.strategy.triplea.ai.weak.WeakAi;

public class OEPAI extends AbstractOEPAi{

  public OEPAI(String name) {

    super(name);
    ProLogger.info("Starting MCTSAI class");
  }
}
