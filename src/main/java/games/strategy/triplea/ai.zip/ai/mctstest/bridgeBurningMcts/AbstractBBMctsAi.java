package games.strategy.triplea.ai.mctstest.bridgeBurningMcts;

import games.strategy.engine.data.GameData;
import games.strategy.engine.data.GamePlayer;
import games.strategy.engine.data.Unit;
import games.strategy.engine.framework.GameDataUtils;
import games.strategy.triplea.ai.mctstest.MctsAi;
import games.strategy.triplea.ai.mctstest.algorithm.ActionWrapper;
import games.strategy.triplea.ai.mctstest.algorithm.Mcts;
import games.strategy.triplea.ai.mctstest.algorithm.WorldModel;
import games.strategy.triplea.ai.mctstest.forwardmodel.ForwardModel;
import games.strategy.triplea.ai.mctstest.forwardmodel.MctsData;
import games.strategy.triplea.ai.pro.logging.ProLogger;
import games.strategy.triplea.ai.weak.WeakAi;
import games.strategy.triplea.delegate.remote.IMoveDelegate;
import java.util.logging.Level;
import lombok.Getter;

public class AbstractBBMctsAi extends MctsAi {

  private Mcts mcts;

  private final MctsData mctsData;

  public AbstractBBMctsAi(final String name, final MctsData mctsData) {

    super(name);
    ProLogger.info("Starting ABSTRACTMCTSAI class");
    this.mctsData=mctsData;
  }


  @Override
  protected void move(
      final boolean nonCombat,
      final IMoveDelegate moveDel,
      final GameData data,
      final GamePlayer player) {
    super.stopGame(); // absolutely MUST call super.stopGame() first
    ProLogger.info("Starting Move phase");
    MctsData mctsData= new MctsData(data);
    mctsData.initialize(data);
    final GameData dataCopy;
    try {
      data.acquireWriteLock();
      dataCopy = GameDataUtils.cloneGameDataWithoutHistory(data, true);
    } catch (final Throwable t) {
      ProLogger.log(Level.WARNING, "Error trying to clone game data for simulating phases", t);
      throw new NullPointerException();
      //return;
    } finally {
      data.releaseWriteLock();
    }

        /*
        try {
            Thread.sleep(10000);
        } catch (Exception e){
        }*/

    this.mcts=new BridgeBurningMcts(new WorldModel(dataCopy));
    this.mcts.initializeMCTSearch();
    ProLogger.info("Selection Action");
    ActionWrapper best=mcts.run();

    System.out.println(best==null);
    //ProLogger.info("Action selected"+best.getU().toString()+"  ;  "+ best.getT().toString() );
    ProLogger.info("is best action null: "+(best==null)+"");

    if (best==null){
      if (best==null) {
        //throw new NullPointerException();
      }
      return;
    }
    for (Unit u:best.actions.keySet()){

      ProLogger.info("best actions details: "+u + ", "+best.actions.get(u));

    }

    final long start = System.currentTimeMillis();
    ProLogger.info("movemap size " + ForwardModel.attackToMove(best.actions, mctsData).size() );
    ForwardModel.doMove(ForwardModel.attackToMove(best.replaceUnits(data).actions, mctsData), moveDel, player, data, mctsData, false);

    ProLogger.info(
        player.getName()
            + " time for nonCombat="
            + nonCombat
            + " time="
            + (System.currentTimeMillis() - start));

  }
}
