package games.strategy.triplea.ai.mctstest.nonExploring;

import games.strategy.triplea.ai.mctstest.algorithm.Action;
import games.strategy.triplea.ai.mctstest.algorithm.ActionWrapper;
import games.strategy.triplea.ai.mctstest.algorithm.MCTSNode;
import games.strategy.triplea.ai.mctstest.algorithm.Reward;
import games.strategy.triplea.ai.mctstest.algorithm.WorldModel;
import games.strategy.triplea.ai.pro.logging.ProLogger;
import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Random;
import games.strategy.triplea.ai.mctstest.algorithm.Mcts;

public class NonExploringMcts extends Mcts{


  public NonExploringMcts(WorldModel worldModel){
    super(worldModel);
  }


  @Override
  protected MCTSNode Selection(MCTSNode initialNode)
  {
    ProLogger.info("------------------------------------> Started selection phase");
    ProLogger.info("------------------------------------> root node phase - "+initialNode.state.data.getSequence().getStep().getName());
    Action nextAction;
    MCTSNode currentNode = initialNode;
    MCTSNode bestChild;


    while(!currentNode.state.isTerminal())
    {
      if(initialNode.state.data.getSequence().getRound()==currentNode.state.data.getSequence().getRound()){
        this.CurrentDepth++;
        nextAction = currentNode.state.getNextAction();

        if(nextAction != null )
        {
          ProLogger.info("------------------------------------> expanded new node");
          if(nextAction != null){
            ProLogger.info(nextAction.toString());
          } else {
            ProLogger.info("null action");
          }
          return this.Expand(currentNode, nextAction);

        }
      }

      bestChild = this.bestUCTChild(currentNode);
      if (bestChild == null)
      {
        ProLogger.info("------------------------------------> returned final tree node");
        if (currentNode.action==null){
          ProLogger.info("------------------------------------> null action");
        } else {
          ProLogger.info(currentNode.action.toString());
        }
        ProLogger.info("------------------------------------> number of child nodes - "+currentNode.ChildNodes.size());
        return currentNode;

      }
      else
      {
        ProLogger.info("------------------------------------> selected new tree node");
        currentNode = bestChild;
        ProLogger.info(currentNode.action.toString());
        ProLogger.info("------------------------------------> best child phase - "+currentNode.state.data.getSequence().getStep().getName());
      }

    }

    return currentNode;
  }

  @Override
  protected Reward Playout(WorldModel initialPlayoutState)
  {
    ArrayList<Action> executableActions;
    int randomIndex;
    WorldModel state = initialPlayoutState.generateChildWorldModel();
    int i=0;
    while(!state.isTerminal() || i<15)
    {
      i++;
      executableActions = state.getExecutableActions();
      if(executableActions.size() > 0)
      {
        this.CurrentDepth++;
        executableActions.get(0).applyActionEffectsSingular(state);
        //Action.throwshit();
      }
      else
      {
        break;
      }
    }

    // meter reward
    //return new Reward(0, state.getScore());
    return new Reward(0, Math.random());
  }




}



