package games.strategy.triplea.ai.mctsclean.oepMcts;

import games.strategy.engine.data.GamePlayer;
import games.strategy.engine.data.Territory;
import games.strategy.engine.data.Unit;
import games.strategy.triplea.ai.mctsclean.algorithm.Action;
import games.strategy.triplea.ai.mctsclean.algorithm.NewAction;
import games.strategy.triplea.ai.mctsclean.algorithm.Reward;
import games.strategy.triplea.ai.mctsclean.algorithm.WorldModel;
import games.strategy.triplea.ai.pro.logging.ProLogger;
import games.strategy.triplea.ai.weak.WeakAi;
import games.strategy.triplea.delegate.Matches;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.triplea.java.collections.CollectionUtils;

public class Oep {

  static final int GENE_SIZE=25;
  static final int executionTime=100000;
  static final double mutationP=0.5;
  private static final WeakAi weakAi= new WeakAi("");
  private static GamePlayer player;

  public Oep(){

  };

  public static double eval(OepWorldModel state){
    return Playout(state);
  }

  protected static double Playout(OepWorldModel state)
  {
    ArrayList<NewAction> executableActions;
    int randomIndex;
    int i=0;

    WeakAi.ss="";
    while(!state.isTerminal() && i<40)
    {
      i++;
      state.doMoveWeakAi(weakAi);
      OepWorldModel.advancePlayout(state);
    }

    if (state.isTerminal()){
      if (state.victors.contains(player)){
        return 0.5+0.5*((40-i)/40);
      }
      return -0.5-0.5*((40-i)/40);
    }

    Set<Unit> set = new HashSet<>();
    for (Territory t:state.data.getMap()){
      set.addAll(t.getUnits());
    }
    float unitSize= CollectionUtils.getMatches(set, Matches.unitOwnedBy(player)).size();
    float enemyUnitSize=set.size()-unitSize;

    return (unitSize-enemyUnitSize)/(set.size() * 2);
  }

  public ArrayList<OepAction> run(OepWorldModel state){
    player=state.data.getSequence().getStep().getPlayerId();
    state.generateMoves();
    List<Genome> genes= new ArrayList<>();
    init(genes, state);
    float startTime=System.currentTimeMillis();
    while (true){
      for(Genome g:genes){
        OepWorldModel newState=state.generateChildWorldModel();
        g.executeActions(newState);
        if (g.visits>0){
          g.value=eval(newState);
        }
        g.visits++;
      }
      if (System.currentTimeMillis()-startTime>executionTime){
        break;
      }
      Collections.sort(genes,Collections.reverseOrder());
      int size=genes.size();
      List<Genome> newGenes= genes.subList(0,size/2);
      genes=procreate(newGenes);
      ProLogger.info("created new genome");
    }
    return genes.get(0).actions;

  }

  public List<Genome> procreate(List<Genome> genes){
    ArrayList<Genome> newGenes=new ArrayList<>();
    for(Genome g:genes){
      ArrayList<OepAction> newActions=new ArrayList<>();
      Genome otherGenome=genes.get((int)(Math.random()*genes.size()));
      for(int i=0;i<g.actions.size();i++){
        if(Math.random()>0.5){
          newActions.add(g.actions.get(i));
        } else {
          newActions.add(otherGenome.actions.get(i));
        }
      }

      if(Math.random()>mutationP){
        //Gerar ação random e mudar
      }
      newGenes.add(new Genome(newActions));

    }
    genes.addAll(newGenes);
    return genes;
  }

  public void init(List<Genome> genes, OepWorldModel state){
    for (int i=0;i<GENE_SIZE;i++){
      Genome g= new Genome(state);
      genes.add(g);
    }
  }
}
