package games.strategy.triplea.ai.mctstest.algorithm;

public class Reward{

    public int id;
    public double value;
    public Reward(int id, double value){
        this.id=id;
        this.value=value;
    }
    //implementar
    public int getRewardForNode(MCTSNode node){
        return 0;
    }
}