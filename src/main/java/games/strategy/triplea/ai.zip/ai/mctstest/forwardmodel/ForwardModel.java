package games.strategy.triplea.ai.mctstest.forwardmodel;

import games.strategy.engine.data.*;
import games.strategy.engine.data.changefactory.ChangeFactory;
import games.strategy.engine.delegate.IDelegateBridge;
import games.strategy.engine.player.Player;
import games.strategy.triplea.Constants;
import games.strategy.triplea.ai.mctstest.MctsAi;
import games.strategy.triplea.ai.mctstest.algorithm.Action;
import games.strategy.triplea.ai.mctstest.algorithm.WorldModel;
import games.strategy.triplea.ai.pro.ProData;
import games.strategy.triplea.ai.pro.data.ProBattleResult;
import games.strategy.triplea.ai.pro.data.ProTerritory;
import games.strategy.triplea.ai.pro.logging.ProLogger;
import games.strategy.triplea.ai.pro.simulate.ProDummyDelegateBridge;
import games.strategy.triplea.ai.pro.util.ProMatches;
import games.strategy.triplea.ai.pro.util.ProOddsCalculator;
import games.strategy.triplea.attachments.TerritoryAttachment;
import games.strategy.triplea.attachments.UnitAttachment;
import games.strategy.triplea.delegate.DelegateFinder;
import games.strategy.triplea.delegate.DiceRoll;
import games.strategy.triplea.delegate.Matches;
import games.strategy.triplea.delegate.OriginalOwnerTracker;
import games.strategy.triplea.delegate.TerritoryEffectHelper;
import games.strategy.triplea.delegate.battle.BattleDelegate;
import games.strategy.triplea.delegate.battle.BattleTracker;
import games.strategy.triplea.delegate.battle.IBattle;
import games.strategy.triplea.delegate.battle.UnitBattleComparator;
import games.strategy.triplea.delegate.remote.IMoveDelegate;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import javax.annotation.Nullable;
import org.triplea.java.collections.CollectionUtils;
import org.triplea.java.collections.IntegerMap;

public class ForwardModel {

    protected final GameData gameData;

    private final MctsData mctsData;
    private ModelTerritoryManager territoryManager;

    final Map<GamePlayer, Player> gamePlayers;
    final IMoveDelegate moveDel;
    public static MctsAi mctsAi;

    public ForwardModel(
            final GameData data,
            final Map<GamePlayer, Player> gamePlayers){
        this.gameData=data;
        this.mctsData=new MctsData();
        this.gamePlayers=gamePlayers;
        this.moveDel= DelegateFinder.moveDelegate(data);
    }

    public void doMove(final List<MoveDescription> moves) {

        // Group non-amphib units of the same type moving on the same route
        // TODO: #5499 Use MoveBatcher here - or ideally at the time the moves are being generated.
        final boolean noTransportLoads =
                moves.stream().allMatch(move -> move.getUnitsToTransports().isEmpty());
        if (noTransportLoads) {
            for (int i = 0; i < moves.size(); i++) {
                final Route r = moves.get(i).getRoute();
                for (int j = i + 1; j < moves.size(); j++) {
                    final Route r2 = moves.get(j).getRoute();
                    if (r.equals(r2)) {
                        final var mergedUnits = new ArrayList<Unit>();
                        mergedUnits.addAll(moves.get(j).getUnits());
                        mergedUnits.addAll(moves.get(i).getUnits());
                        moves.set(j, new MoveDescription(mergedUnits, r));
                        moves.remove(i);
                        i--;
                        break;
                    }
                }
            }
        }

        // Move units
        for (final MoveDescription move : moves) {
            final String result = moveDel.performMove(move);
            if (result != null) {
                ProLogger.warn(
                        gameData.getSequence().getRound()
                                + "-"
                                + gameData.getSequence().getStep().getName()
                                + ": could not move "
                                + move.getUnits()
                                + " over "
                                + move.getRoute()
                                + " because: "
                                + result);
            }
        }
    }

    public void generateMoves(){
        territoryManager = new ModelTerritoryManager(mctsData);
        if(gameData.getSequence().getStep().getName().endsWith("NonCombatMove")){
            territoryManager.populateDefenseOptions(new ArrayList<>());
        } else if(gameData.getSequence().getStep().getName().endsWith("CombatMove") && !gameData.getSequence().getStep().getName().endsWith("AirborneCombatMove")){
            territoryManager.populateAttackOptions();
        } else if(gameData.getSequence().getStep().getName().endsWith("Battle")){

        } else if(gameData.getSequence().getStep().getName().endsWith("Place") || gameData.getSequence().getStep().getName().endsWith("EndTurn")){

        } else if(gameData.getSequence().getStep().getName().endsWith("Politics")){

        }
        territoryManager.populateAttackOptions();


    }


    //mudar isto / implementar
    public static void generateMoves(MctsData mctsData, GameData gameData){
        ModelTerritoryManager territoryManager = new ModelTerritoryManager(mctsData);
        if(gameData.getSequence().getStep().getName().endsWith("NonCombatMove")){
            territoryManager.populateDefenseOptions(new ArrayList<>());
        } else if(gameData.getSequence().getStep().getName().endsWith("CombatMove") && !gameData.getSequence().getStep().getName().endsWith("AirborneCombatMove")){
            territoryManager.populateAttackOptions();
        } else if(gameData.getSequence().getStep().getName().endsWith("Battle")){

        } else if(gameData.getSequence().getStep().getName().endsWith("Place") || gameData.getSequence().getStep().getName().endsWith("EndTurn")){

        } else if(gameData.getSequence().getStep().getName().endsWith("Politics")){

        }
        territoryManager.populateAttackOptions();


    }

    //mudar isto / implementar
    public static void generateMoves(ModelTerritoryManager territoryManager, GameData gameData){
        if(gameData.getSequence().getStep().getName().endsWith("NonCombatMove")){
            territoryManager.populateDefenseOptions(new ArrayList<>());
        } else if(gameData.getSequence().getStep().getName().endsWith("CombatMove") && !gameData.getSequence().getStep().getName().endsWith("AirborneCombatMove")){
            territoryManager.populateAttackOptions();
        } else if(gameData.getSequence().getStep().getName().endsWith("Battle")){

        } else if(gameData.getSequence().getStep().getName().endsWith("Place") || gameData.getSequence().getStep().getName().endsWith("EndTurn")){

        } else if(gameData.getSequence().getStep().getName().endsWith("Politics")){

        }
        territoryManager.populateAttackOptions();


    }

    public void doMove(final Map<Territory, ModelTerritory> moveMap,
                       final IMoveDelegate moveDel,
                       final GamePlayer player){
        if(gameData.getSequence().getStep().getName().endsWith("NonCombatMove")){
            ModelMoveUtils.doMove(
                    mctsData, ModelMoveUtils.calculateMoveRoutes(mctsData, player, moveMap, false), moveDel, true);

            // Calculate amphib move routes and perform moves
            ModelMoveUtils.doMove(
                    mctsData, ModelMoveUtils.calculateAmphibRoutes(mctsData, player, moveMap, false), moveDel, true);

        } else if(gameData.getSequence().getStep().getName().endsWith("CombatMove") && !gameData.getSequence().getStep().getName().endsWith("AirborneCombatMove")){
            ModelMoveUtils.doMove(
                    mctsData, ModelMoveUtils.calculateMoveRoutes(mctsData, player, moveMap, true), moveDel, true);
            ModelMoveUtils.doMove(
                    mctsData, ModelMoveUtils.calculateAmphibRoutes(mctsData, player, moveMap, true), moveDel, true);
            ModelMoveUtils.doMove(
                    mctsData, ModelMoveUtils.calculateBombardMoveRoutes(mctsData, player, moveMap), moveDel, true);
            ModelMoveUtils.doMove(
                    mctsData, ModelMoveUtils.calculateBombingRoutes(mctsData, player, moveMap), moveDel, true);
        }

        // Calculate move routes and perform moves
    }

    public static void doMove(final Map<Territory, ModelTerritory> moveMap,
                              final IMoveDelegate moveDel,
                              final GamePlayer player, GameData gameData, MctsData mctsData, boolean isSimulation){
        if(isSimulation){
            //return;
            final IDelegateBridge bridge = new MctsDummyDelegateBridge(mctsAi, gameData.getSequence().getStep().getPlayerId(), gameData);
            moveDel.setDelegateBridgeAndPlayer(bridge);
        }

        if(gameData.getSequence().getStep().getName().endsWith("NonCombatMove")){
            ModelMoveUtils.doMove(
                    mctsData, ModelMoveUtils.calculateMoveRoutes(mctsData, player, moveMap, false), moveDel, isSimulation);

            // Calculate amphib move routes and perform moves
            ModelMoveUtils.doMove(
                    mctsData, ModelMoveUtils.calculateAmphibRoutes(mctsData, player, moveMap, false), moveDel, isSimulation);
            ProLogger.info("did non combat move");

        } else if(gameData.getSequence().getStep().getName().endsWith("CombatMove") && !gameData.getSequence().getStep().getName().endsWith("AirborneCombatMove")){
            ProLogger.info("move utils size " + ModelMoveUtils.calculateMoveRoutes(mctsData, player, moveMap, true) );
            ModelMoveUtils.doMove(
                    mctsData, ModelMoveUtils.calculateMoveRoutes(mctsData, player, moveMap, true), moveDel, isSimulation);
            ModelMoveUtils.doMove(
                    mctsData, ModelMoveUtils.calculateAmphibRoutes(mctsData, player, moveMap, true), moveDel, isSimulation);
            ModelMoveUtils.doMove(
                    mctsData, ModelMoveUtils.calculateBombardMoveRoutes(mctsData, player, moveMap), moveDel, isSimulation);
            ModelMoveUtils.doMove(
                    mctsData, ModelMoveUtils.calculateBombingRoutes(mctsData, player, moveMap), moveDel, isSimulation);

            ProLogger.info("did combat move");
        }

        // Calculate move routes and perform moves
    }

    public static Map<Territory, ModelTerritory> attackToMove(Map<Unit, Territory> unitMoveMap, MctsData mctsData){
        Map<Territory, ModelTerritory> moveMap= new HashMap<Territory, ModelTerritory>();
        for (Unit u:unitMoveMap.keySet()) {
            if (moveMap.containsKey(unitMoveMap.get(u))){
                moveMap.get(unitMoveMap.get(u)).addMaxUnit(u);
            }
            else {
                final ModelTerritory moveTerritoryData = new ModelTerritory(unitMoveMap.get(u), mctsData);
                moveTerritoryData.addMaxUnit(u);
                moveTerritoryData.addUnit(u);
                moveMap.put(unitMoveMap.get(u), moveTerritoryData);
            }

        }
        return moveMap;
    }

    public static Map<Territory, ModelTerritory> attackToMoveSingular(Unit u, Territory t, MctsData mctsData){
        Map<Territory, ModelTerritory> moveMap= new HashMap<Territory, ModelTerritory>();
        final ModelTerritory moveTerritoryData = new ModelTerritory(t, mctsData);
        moveTerritoryData.addMaxUnit(u);
        moveTerritoryData.addUnit(u);
        moveMap.put(t, moveTerritoryData);
        return moveMap;
    }

    /*
    public static void simulateBattles(
        final MctsData proData,
        final GameData data,
        final GamePlayer player,
        final IDelegateBridge delegateBridge,
        final ProOddsCalculator calc) {

        ProLogger.info("Starting battle simulation phase");

        final BattleDelegate battleDelegate = DelegateFinder.battleDelegate(data);
        final Map<IBattle.BattleType, Collection<Territory>> battleTerritories =
            battleDelegate.getBattles().getBattles();
        for (final Map.Entry<IBattle.BattleType, Collection<Territory>> entry : battleTerritories.entrySet()) {
            for (final Territory t : entry.getValue()) {
                final IBattle battle =
                    battleDelegate
                        .getBattleTracker()
                        .getPendingBattle(t, entry.getKey().isBombingRun(), entry.getKey());
                final Collection<Unit> attackers = new ArrayList<>(battle.getAttackingUnits());
                attackers.retainAll(t.getUnits());
                final Collection<Unit> defenders = new ArrayList<>(battle.getDefendingUnits());
                defenders.retainAll(t.getUnits());
                final Collection<Unit> bombardingUnits = battle.getBombardingUnits();
                ProLogger.debug("---" + t);
                ProLogger.debug("attackers=" + attackers);
                ProLogger.debug("defenders=" + defenders);
                ProLogger.debug("bombardingUnits=" + bombardingUnits);

                final ProBattleResult result =
                    calc.callBattleCalc(proData, t, attackers, defenders, bombardingUnits);
                final Collection<Unit> remainingAttackers = result.getAverageAttackersRemaining();
                final Collection<Unit> remainingDefenders = result.getAverageDefendersRemaining();
                ProLogger.debug("remainingAttackers=" + remainingAttackers);
                ProLogger.debug("remainingDefenders=" + remainingDefenders);

                // Make updates to data
                final List<Unit> attackersToRemove = new ArrayList<>(attackers);
                attackersToRemove.removeAll(remainingAttackers);
                final List<Unit> defendersToRemove =
                    CollectionUtils.getMatches(defenders, Matches.unitIsInfrastructure().negate());
                defendersToRemove.removeAll(remainingDefenders);
                final List<Unit> infrastructureToChangeOwner =
                    CollectionUtils.getMatches(defenders, Matches.unitIsInfrastructure());
                ProLogger.debug("attackersToRemove=" + attackersToRemove);
                ProLogger.debug("defendersToRemove=" + defendersToRemove);
                ProLogger.debug("infrastructureToChangeOwner=" + infrastructureToChangeOwner);
                final Change attackersKilledChange = ChangeFactory.removeUnits(t, attackersToRemove);
                delegateBridge.addChange(attackersKilledChange);
                final Change defendersKilledChange = ChangeFactory.removeUnits(t, defendersToRemove);
                delegateBridge.addChange(defendersKilledChange);
                BattleTracker.captureOrDestroyUnits(t, player, player, delegateBridge, null);
                if (!checkIfCapturedTerritoryIsAlliedCapital(t, data, player, delegateBridge)) {
                    delegateBridge.addChange(ChangeFactory.changeOwner(t, player));
                }
                battleDelegate.getBattleTracker().getConquered().add(t);
                battleDelegate.getBattleTracker().removeBattle(battle, data);
                final Territory updatedTerritory = data.getMap().getTerritory(t.getName());
                ProLogger.debug(
                    "after changes owner="
                        + updatedTerritory.getOwner()
                        + ", units="
                        + updatedTerritory.getUnits());
            }
        }
    }*/

    private static boolean checkIfCapturedTerritoryIsAlliedCapital(
        final Territory t,
        final GameData data,
        final GamePlayer player,
        final IDelegateBridge delegateBridge) {

        final @Nullable GamePlayer terrOrigOwner = OriginalOwnerTracker.getOriginalOwner(t);
        final RelationshipTracker relationshipTracker = data.getRelationshipTracker();
        final TerritoryAttachment ta = TerritoryAttachment.get(t);
        if (ta != null
            && ta.getCapital() != null
            && terrOrigOwner != null
            && TerritoryAttachment.getAllCapitals(terrOrigOwner, data).contains(t)
            && relationshipTracker.isAllied(terrOrigOwner, player)) {

            // Give capital and any allied territories back to original owner
            final Collection<Territory> originallyOwned =
                OriginalOwnerTracker.getOriginallyOwned(data, terrOrigOwner);
            final List<Territory> friendlyTerritories =
                CollectionUtils.getMatches(
                    originallyOwned, Matches.isTerritoryAllied(terrOrigOwner, data));
            friendlyTerritories.add(t);
            for (final Territory item : friendlyTerritories) {
                if (item.getOwner().equals(terrOrigOwner)) {
                    continue;
                }
                final Change takeOverFriendlyTerritories = ChangeFactory.changeOwner(item, terrOrigOwner);
                delegateBridge.addChange(takeOverFriendlyTerritories);
                final Collection<Unit> units =
                    CollectionUtils.getMatches(item.getUnits(), Matches.unitIsInfrastructure());
                if (!units.isEmpty()) {
                    final Change takeOverNonComUnits = ChangeFactory.changeOwner(units, terrOrigOwner, t);
                    delegateBridge.addChange(takeOverNonComUnits);
                }
            }
            return true;
        }
        return false;
    }


    public static Map<Unit, Set<Territory>> sortUnitNeededOptionsThenAttack(
        final MctsData proData,
        final GamePlayer player,
        final Map<Unit, Set<Territory>> unitAttackOptions,
        final Map<Territory, ModelTerritory> attackMap) {
        final GameData data = proData.getData();
        final Map<Unit, Territory> unitTerritoryMap = proData.getUnitTerritoryMap();
        final List<Map.Entry<Unit, Set<Territory>>> list =
            new ArrayList<>(unitAttackOptions.entrySet());
        list.sort(
            (o1, o2) -> {
                final Collection<Territory> territories =attackMap.keySet();
                final Unit unit1 = o1.getKey();
                final Unit unit2 = o2.getKey();
                final UnitType unitType1 = unit1.getType();
                final UnitType unitType2 = unit2.getType();

                // If unit types are equal and are air, then sort by average distance.
                if (unitType1.equals(unitType2) && UnitAttachment.get(unitType1).getIsAir()) {
                    final Predicate<Territory> predicate =
                        ProMatches.territoryCanMoveAirUnitsAndNoAa(player, data, true);
                    final Territory territory1 = unitTerritoryMap.get(unit1);
                    final Territory territory2 = unitTerritoryMap.get(unit2);
                    int distance1 = 0;
                    for (final Territory t : territories) {
                        distance1 += data.getMap().getDistanceIgnoreEndForCondition(territory1, t, predicate);
                    }
                    int distance2 = 0;
                    for (final Territory t : territories) {
                        distance2 += data.getMap().getDistanceIgnoreEndForCondition(territory2, t, predicate);
                    }
                    if (distance1 != distance2) {
                        return distance1 - distance2;
                    }
                }

                return unitType1.getName().compareTo(unitType2.getName());
            });
        final Map<Unit, Set<Territory>> sortedUnitAttackOptions = new LinkedHashMap<>();
        for (final Map.Entry<Unit, Set<Territory>> entry : list) {
            sortedUnitAttackOptions.put(entry.getKey(), entry.getValue());
        }
        return sortedUnitAttackOptions;
    }


}
