package games.strategy.triplea.ai.mctstest.algorithm;

import games.strategy.engine.data.Change;
import games.strategy.engine.data.GameData;
import games.strategy.engine.data.GamePlayer;
import games.strategy.engine.data.GameStep;
import games.strategy.engine.data.Resource;
import games.strategy.engine.data.Territory;
import games.strategy.engine.data.Unit;
import games.strategy.engine.data.changefactory.ChangeFactory;
import games.strategy.engine.delegate.IDelegate;
import games.strategy.engine.delegate.IDelegateBridge;
import games.strategy.triplea.Constants;
import games.strategy.triplea.ai.fast.FastOddsEstimator;
import games.strategy.triplea.ai.mctstest.MctsAi;
import games.strategy.triplea.ai.mctstest.forwardmodel.ForwardModel;
import games.strategy.triplea.ai.mctstest.forwardmodel.MctsDummyDelegateBridge;
import games.strategy.triplea.ai.pro.ProData;
import games.strategy.triplea.ai.pro.data.ProBattleResult;
import games.strategy.triplea.ai.pro.logging.ProLogger;
import games.strategy.triplea.ai.pro.simulate.ProDummyDelegateBridge;
import games.strategy.triplea.ai.pro.simulate.ProSimulateTurnUtils;
import games.strategy.triplea.ai.pro.util.ProOddsCalculator;
import games.strategy.triplea.delegate.DelegateFinder;
import games.strategy.triplea.delegate.Matches;
import games.strategy.triplea.delegate.battle.BattleDelegate;
import games.strategy.triplea.delegate.battle.BattleTracker;
import games.strategy.triplea.delegate.battle.IBattle;
import games.strategy.triplea.delegate.data.BattleListing;
import games.strategy.triplea.delegate.data.FightBattleDetails;
import games.strategy.triplea.delegate.remote.IBattleDelegate;
import games.strategy.triplea.delegate.remote.IPurchaseDelegate;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import lombok.Getter;
import org.triplea.java.collections.CollectionUtils;
import org.triplea.sound.ClipPlayer;
import org.triplea.sound.SoundPath;
import games.strategy.triplea.ai.weak.WeakAi;
import games.strategy.triplea.delegate.remote.IAbstractPlaceDelegate;
import games.strategy.triplea.player.AbstractBasePlayer;

@Getter
public  class Action{

    protected Unit u;
    protected Territory t;
    protected int n;
    static boolean intermediate=false;

    //implementar
    public Action(Unit u, Territory t){
        this.u=u;
        this.t=t;
    }

    public void applyActionEffectsSingular(WorldModel state){

        GameStep gameStep =getNextStep(state);
        WeakAi weakAi= new WeakAi("test");

        if (this.u!=null){
            ForwardModel.doMove(ForwardModel.attackToMoveSingular(state.data.getUnits().get(u.getId()), (Territory) state.data.getUnitHolder(t.getName(),"T"), state.mctsData), state.moveDel, state.data.getSequence().getStep().getPlayerId(), state.data, state.mctsData, true);
        }
        state.data.getSequence().next();
        /*state.data
            .getSequence()
            .setRoundAndStep(
                state.data.getSequence().getRound(), gameStep.getDisplayName(), gameStep.getPlayerId());

         */

        while(!gameStep.getName().endsWith("NonCombatMove") && !gameStep.getName().endsWith("CombatMove")){
            //ProLogger.info("-------------------------------------->>  stage " + state.data.getSequence().getStep().getName());
            if (gameStep.getName().endsWith("Battle")) {

                simulateBattles(state.data,state.data.getSequence().getStep().getPlayerId(), state.moveDel.getBridge());
            } else if (gameStep.getName().endsWith("Place")){
                //ProLogger.info("did place");
                IAbstractPlaceDelegate placeDel = (IAbstractPlaceDelegate) state.data.getDelegate("place");
                final IDelegateBridge bridge = new MctsDummyDelegateBridge(MctsAi.currentInstance, state.data.getSequence().getStep().getPlayerId(), state.data);
                placeDel.setDelegateBridgeAndPlayer(bridge);
                if (placeDel == null) {
                    throw new IllegalStateException("place delegate not found");
                }

                weakAi.place(gameStep.getName().contains("Bid"), placeDel,state.data,state.data.getSequence().getStep().getPlayerId());

            } else if (gameStep.getName().endsWith("Bid")) {
                //ProLogger.info("did bid");
                final IPurchaseDelegate purchaseDel2 = (IPurchaseDelegate) state.data.getDelegate("purchase");
                if (purchaseDel2 == null) {
                    throw new IllegalStateException("place delegate not found");
                }
                String propertyName = state.data.getSequence().getStep().getPlayerId().getName() + " bid";
                int bidAmount = state.data.getProperties().get(propertyName, 0);
                weakAi.purchase(true,bidAmount ,purchaseDel2,state.data,state.data.getSequence().getStep().getPlayerId());
            } else if (gameStep.getName().endsWith("Purchase")){
                //ProLogger.info("did purchase");
                final IPurchaseDelegate purchaseDel = (IPurchaseDelegate) state.data.getDelegate("purchase");
                if (purchaseDel == null) {
                    throw new IllegalStateException("place delegate not found");
                }
                purchaseDel.setDelegateBridgeAndPlayer(new MctsDummyDelegateBridge(ForwardModel.mctsAi, state.data.getPlayerList().getPlayerId(state.data.getSequence().getStep().getPlayerId().getName()), state.data));
                Resource pus = state.data.getResourceList().getResource(Constants.PUS);
                int leftToSpend = state.data.getSequence().getStep().getPlayerId().getResources().getQuantity(pus);
                weakAi.purchase(false,leftToSpend ,purchaseDel,state.data,state.data.getSequence().getStep().getPlayerId());
            }
            gameStep = getNextStep(state);
            state.data.getSequence().next();
            /*state.data
                .getSequence()
                .setRoundAndStep(
                    state.data.getSequence().getRound(), gameStep.getDisplayName(), gameStep.getPlayerId());

             */

        }
        //ProLogger.info("-------------------------------------->>>  stage " + state.data.getSequence().getStep().getName());



        state.generateactions();

    }

    public GameStep getNextStep(WorldModel state){
        if (state.data.getSequence().getStepIndex()+1>=state.data.getSequence().size()){
            return state.data.getSequence().getStep(state.data.getSequence().getStepIndex()+1-state.data.getSequence().size());
        }
        return state.data.getSequence().getStep(state.data.getSequence().getStepIndex()+1);
    }

    public static void throwshit(){
        throw new NullPointerException();
    }


    private void battle(WorldModel state) {
        final IBattleDelegate battleDel;
        battleDel = DelegateFinder.battleDelegate(state.data);
        battleDel.setDelegateBridgeAndPlayer(new MctsDummyDelegateBridge(ForwardModel.mctsAi, state.data.getPlayerList().getPlayerId(state.data.getSequence().getStep().getPlayerId().getName()), state.data));



        //final GamePlayer gamePlayer = state.data.getSequence().getStep().getPlayerId();

        final Map<IBattle.BattleType, Collection<Territory>> battleTerritories =
            battleDel.getBattles().getBattles();

        for (final Map.Entry<IBattle.BattleType, Collection<Territory>> entry : battleTerritories.entrySet()) {
            for (final Territory t : entry.getValue()) {
                //ProLogger.info("battle "+t.getName()+", "+entry.getKey());
                //continue;

                battleDel.fightBattle(
                    t, entry.getKey().isBombingRun(), entry.getKey());

            }
        }

    }

    public static void simulateBattles(
        final GameData data,
        final GamePlayer player,
        final IDelegateBridge delegateBridge) {

        ProData proData= new ProData();
        proData.hiddenInitialize(data, player, true);
        ProLogger.info("Starting battle simulation phase");
        final ProOddsCalculator calc= new ProOddsCalculator(new FastOddsEstimator(proData));

        final BattleDelegate battleDelegate = DelegateFinder.battleDelegate(data);
        final Map<IBattle.BattleType, Collection<Territory>> battleTerritories =
            battleDelegate.getBattles().getBattles();
        for (final Map.Entry<IBattle.BattleType, Collection<Territory>> entry : battleTerritories.entrySet()) {
            for (final Territory t : entry.getValue()) {
                final IBattle battle =
                    battleDelegate
                        .getBattleTracker()
                        .getPendingBattle(t, entry.getKey().isBombingRun(), entry.getKey());
                final Collection<Unit> attackers = new ArrayList<>(battle.getAttackingUnits());
                attackers.retainAll(t.getUnits());
                final Collection<Unit> defenders = new ArrayList<>(battle.getDefendingUnits());
                defenders.retainAll(t.getUnits());
                final Collection<Unit> bombardingUnits = battle.getBombardingUnits();
                ProLogger.debug("---" + t);
                ProLogger.debug("attackers=" + attackers);
                ProLogger.debug("defenders=" + defenders);
                ProLogger.debug("bombardingUnits=" + bombardingUnits);

                final ProBattleResult result =
                    calc.callBattleCalc(proData, t, attackers, defenders, bombardingUnits);
                final Collection<Unit> remainingAttackers = result.getAverageAttackersRemaining();
                final Collection<Unit> remainingDefenders = result.getAverageDefendersRemaining();
                ProLogger.debug("remainingAttackers=" + remainingAttackers);
                ProLogger.debug("remainingDefenders=" + remainingDefenders);

                // Make updates to data
                final List<Unit> attackersToRemove = new ArrayList<>(attackers);
                attackersToRemove.removeAll(remainingAttackers);
                final List<Unit> defendersToRemove =
                    CollectionUtils.getMatches(defenders, Matches.unitIsInfrastructure().negate());
                defendersToRemove.removeAll(remainingDefenders);
                final List<Unit> infrastructureToChangeOwner =
                    CollectionUtils.getMatches(defenders, Matches.unitIsInfrastructure());
                ProLogger.debug("attackersToRemove=" + attackersToRemove);
                ProLogger.debug("defendersToRemove=" + defendersToRemove);
                ProLogger.debug("infrastructureToChangeOwner=" + infrastructureToChangeOwner);
                final Change attackersKilledChange = ChangeFactory.removeUnits(t, attackersToRemove);
                delegateBridge.addChange(attackersKilledChange);
                final Change defendersKilledChange = ChangeFactory.removeUnits(t, defendersToRemove);
                delegateBridge.addChange(defendersKilledChange);
                BattleTracker.captureOrDestroyUnits(t, player, player, delegateBridge, null);
                if (!ProSimulateTurnUtils.checkIfCapturedTerritoryIsAlliedCapital(t, data, player, delegateBridge)) {
                    delegateBridge.addChange(ChangeFactory.changeOwner(t, player));
                }
                battleDelegate.getBattleTracker().getConquered().add(t);
                battleDelegate.getBattleTracker().removeBattle(battle, data);
                final Territory updatedTerritory = data.getMap().getTerritory(t.getName());
                ProLogger.debug(
                    "after changes owner="
                        + updatedTerritory.getOwner()
                        + ", units="
                        + updatedTerritory.getUnits());
            }
        }
    }

    @Override
    public String toString(){
        if (u==null){
            return "null action - toString()";
        }
        return "Action t - "+this.u.toString()+" to " +this.t.toString();
    }
}