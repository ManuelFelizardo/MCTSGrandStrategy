package games.strategy.triplea.ai.mctsclean.algorithm;

import games.strategy.engine.data.Territory;
import games.strategy.engine.data.Unit;
import java.util.Set;

public class NewActionAdvance extends NewAction {
  public NewActionAdvance() {
    super(null, null);
  }

  @Override
  public void applyActionEffects(WorldModel state){
    Action.advance(state);
  }



  @Override
  public String toString(){
    return "Advance Action";
  }


}
