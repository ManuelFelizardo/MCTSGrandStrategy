package games.strategy.triplea.ai.mctstest.algorithm;

import games.strategy.engine.data.GameStep;
import games.strategy.engine.data.Territory;
import games.strategy.engine.data.Unit;
import games.strategy.triplea.ai.mctstest.forwardmodel.ForwardModel;
import games.strategy.triplea.ai.pro.logging.ProLogger;
import games.strategy.triplea.ai.weak.WeakAi;
import lombok.Getter;

@Getter
public  class IntermediateAction extends Action {
    static boolean intermediate=true;

    public IntermediateAction(Unit u, Territory t){
        super(u,t);
    }
    //implementar

    /*
    @Override
    public void applyActionEffects(WorldModel state){
        ProLogger.info("Executing intermediate action ,"+ u.toString()+ ", "+t.toString());
        state.actions.addMovement(u,t);
    }
    */


    @Override
    public void applyActionEffectsSingular(WorldModel state){
        if(this.u!=null) {
            ForwardModel.doMove(ForwardModel.attackToMoveSingular(u, t, state.mctsData), state.moveDel, state.data.getSequence().getStep().getPlayerId(), state.data, state.mctsData, true);
        }

    }

    @Override
    public String toString(){
        return "Intermediate "+ super.toString();
    }
}