package games.strategy.triplea.ai.mctstest.algorithm;

import games.strategy.engine.data.GameData;
import games.strategy.engine.data.GamePlayer;
import games.strategy.engine.data.GameStep;
import games.strategy.engine.data.Resource;
import games.strategy.engine.data.Territory;
import games.strategy.engine.data.Unit;
import games.strategy.engine.data.UnitType;
import games.strategy.engine.delegate.IDelegateBridge;
import games.strategy.engine.framework.GameDataUtils;
import games.strategy.triplea.Constants;
import games.strategy.triplea.ai.mctstest.forwardmodel.ForwardModel;
import games.strategy.triplea.ai.mctstest.forwardmodel.MctsData;
import games.strategy.triplea.ai.mctstest.forwardmodel.MctsDummyDelegateBridge;
import games.strategy.triplea.ai.mctstest.forwardmodel.ModelMoveOptions;
import games.strategy.triplea.ai.mctstest.forwardmodel.ModelTerritoryManager;
import games.strategy.triplea.ai.pro.ProData;
import games.strategy.triplea.ai.pro.data.ProPurchaseTerritory;
import games.strategy.triplea.ai.pro.data.ProTerritory;
import games.strategy.triplea.ai.pro.logging.ProLogUi;
import games.strategy.triplea.ai.pro.logging.ProLogger;
import games.strategy.triplea.ai.pro.simulate.ProDummyDelegateBridge;
import games.strategy.triplea.ai.pro.simulate.ProSimulateTurnUtils;
import games.strategy.triplea.ai.pro.util.ProMatches;
import games.strategy.triplea.ai.pro.util.ProPurchaseUtils;
import games.strategy.triplea.ai.weak.WeakAi;
import games.strategy.triplea.attachments.PoliticalActionAttachment;
import games.strategy.triplea.delegate.DelegateFinder;
import games.strategy.triplea.delegate.PoliticsDelegate;
import games.strategy.triplea.delegate.remote.IAbstractPlaceDelegate;
import games.strategy.triplea.delegate.remote.IMoveDelegate;

import games.strategy.triplea.delegate.remote.IPurchaseDelegate;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import org.triplea.java.collections.CollectionUtils;
import org.triplea.java.collections.IntegerMap;

public class WorldModel{

    //private final WeakAi weakAi;
    public GameData data;
    public MctsData mctsData;
    IMoveDelegate moveDel;
    public GamePlayer player;
    public boolean turnEnded=false;
    private ModelTerritoryManager territoryManager;
    public Iterator<Territory> itrTerritory;
    public LinkedList<Unit> myList;
    public LinkedList.LinkedListNode<Unit> currentUnitNode;
    ModelMoveOptions options=null;
    public int counter=0;
    public boolean nullA=false;
    public boolean intermediate=false;

    public WorldModel(GameData data){
        this.data=data;
        this.mctsData=new MctsData();
        mctsData.initialize(data);
        this.moveDel= DelegateFinder.moveDelegate(data);
        final IDelegateBridge bridge = new MctsDummyDelegateBridge(ForwardModel.mctsAi, data.getPlayerList().getPlayerId(data.getSequence().getStep().getPlayerId().getName()), data);
        moveDel.setDelegateBridgeAndPlayer(bridge);
        myList= new LinkedList<Unit>();
        territoryManager=new ModelTerritoryManager(mctsData);
        String stepName=data.getSequence().getStep().getName();
        if (stepName.endsWith("NonCombatMove")){
            territoryManager.populateDefenseOptions(new ArrayList<>());
            ProLogger.info("iterating over units initialize non combat");
            for(Unit u: territoryManager.getDefendOptions().getUnitMoveMap().keySet()){
                ProLogger.info("unit: " + u.toString());
                myList.addLast(u);
            }
            options=territoryManager.getDefendOptions();
            ProLogger.info("Did non combat prep");
        } else if (stepName.endsWith("CombatMove") && !stepName.endsWith("AirborneCombatMove")){
            territoryManager.populateAttackOptions();
            ProLogger.info("iterating over units initialize combat");
            for(Unit u: territoryManager.getAttackOptions().getUnitMoveMap().keySet()){
                ProLogger.info("unit: " + u.toString());
                myList.addLast(u);
            }
            options=territoryManager.getAttackOptions();
            ProLogger.info("Did combat prep");
        }
        options.sortOptions(mctsData,player);
        this.currentUnitNode=myList.findFirst();

        if (currentUnitNode!=null){
            this.itrTerritory=options.getUnitMoveMap().get(currentUnitNode.data).iterator();
        } else {
            this.itrTerritory=null;
        }
    }

    public WorldModel(GameData data, LinkedList.LinkedListNode<Unit> node, ModelMoveOptions options){
        this.data=data;
        this.currentUnitNode=node;
        this.moveDel= DelegateFinder.moveDelegate(data);
        final IDelegateBridge bridge = new MctsDummyDelegateBridge(ForwardModel.mctsAi, data.getPlayerList().getPlayerId(data.getSequence().getStep().getPlayerId().getName()), data);
        moveDel.setDelegateBridgeAndPlayer(bridge);
        this.mctsData=new MctsData(data);
        mctsData.initialize(data);
        if (options==null){
            throw new NullPointerException();
        } else if (currentUnitNode==null) {

        }
        this.options=options;
        this.itrTerritory=options.getUnitMoveMap().get(currentUnitNode.data).iterator();
        ProLogger.info("logging list of moves");
        ProLogger.info(options.getUnitMoveMap().get(currentUnitNode.data).toString());

    }

    public WorldModel(GameData data, boolean newconstructor){
        this.data=data;
        this.moveDel= DelegateFinder.moveDelegate(data);
        final IDelegateBridge bridge = new MctsDummyDelegateBridge(ForwardModel.mctsAi, data.getPlayerList().getPlayerId(data.getSequence().getStep().getPlayerId().getName()), data);
        moveDel.setDelegateBridgeAndPlayer(bridge);
        this.mctsData=new MctsData(data);
        this.itrTerritory=null;
        mctsData.initialize(data);
        generateactions();


    }

    public void generateactions(){

        this.mctsData=new MctsData();
        this.moveDel= DelegateFinder.moveDelegate(data);
        final IDelegateBridge bridge = new MctsDummyDelegateBridge(ForwardModel.mctsAi, data.getPlayerList().getPlayerId(data.getSequence().getStep().getPlayerId().getName()), data);
        moveDel.setDelegateBridgeAndPlayer(bridge);
        myList= new LinkedList<Unit>();
        String stepName=data.getSequence().getStep().getName();
        mctsData.initialize(data);
        territoryManager=new ModelTerritoryManager(mctsData);

        if (stepName.endsWith("NonCombatMove")){

            territoryManager.populateDefenseOptions(new ArrayList<>());
            ProLogger.info("iterating over units initialize non combat");
            for(Unit u: territoryManager.getDefendOptions().getUnitMoveMap().keySet()){
                ProLogger.info("unit: " + u.toString());
                myList.addLast(u);
            }
            options=territoryManager.getDefendOptions();
            ProLogger.info("Did non combat prep");
        } else if (stepName.endsWith("CombatMove") && !stepName.endsWith("AirborneCombatMove")){
            territoryManager.populateAttackOptions();
            ProLogger.info("iterating over units initialize combat");
            for(Unit u: territoryManager.getAttackOptions().getUnitMoveMap().keySet()){
                ProLogger.info("unit: " + u.toString());
                myList.addLast(u);
            }
            options=territoryManager.getAttackOptions();
            ProLogger.info("Did combat prep");
        }
        options.sortOptions(mctsData,player);

        this.currentUnitNode=myList.findFirst();

        if (currentUnitNode!=null){
            ProLogger.info("current unit node is not null");
            this.itrTerritory=options.getUnitMoveMap().get(currentUnitNode.data).iterator();
            ProLogger.info("itrterritory has next - "+this.itrTerritory.hasNext());
        } else {
            ProLogger.info("current unit node is null");
            this.itrTerritory=null;
        }
        if (options==null){
            throw new NullPointerException("sdfg");
        }

        ProLogger.info("printing next unit");
        ProLogger.info(data.getSequence().getStep().toString());
        if(currentUnitNode==null){
            ProLogger.info("null unit node data");
        }
        //ProLogger.info(currentUnitNode.data.toString());


    }

    //implementar
    public boolean isTerminal(){
        return false;
    }
    //implementar


    public Action getNextAction(){
        //ProLogger.info("itr has next - " + itrTerritory.hasNext());
        if(itrTerritory!=null && itrTerritory.hasNext()){
            if (currentUnitNode.next.data!=null && !this.intermediate){
                this.intermediate=true;

                Action a=new IntermediateAction(currentUnitNode.data,itrTerritory.next());
                return a;

            }else {
                this.intermediate=false;
                Action a=new Action(currentUnitNode.data,itrTerritory.next());

                return a;
            }

        } else if(!this.nullA && currentUnitNode!=null){
            if(!this.intermediate){
                this.intermediate=true;
                return new IntermediateAction(null, null);
            } else{
                this.intermediate=false;
                this.nullA=true;
                return new Action(null, null);
            }
        } else {
            return null;
        }
    }
    //implementar

    public void genExecutableActions(){
        ForwardModel.generateMoves(territoryManager,data);
    }

    public ArrayList<Action> getExecutableActions(){
        ArrayList<Action> actions=new ArrayList<>();
        while(itrTerritory!=null && itrTerritory.hasNext()){
            Territory t=itrTerritory.next();
            if (currentUnitNode.next.data!=null){
                actions.add(new IntermediateAction(currentUnitNode.data,t));
                actions.add(new IntermediateAction(null, null));
            }
            actions.add(new Action(currentUnitNode.data,t));
            actions.add(new Action(null, null));
        }
        return actions;
    }
    //implementar
    public WorldModel generateChildWorldModel(){
        GameData dataCopy;
        dataCopy = GameDataUtils.cloneGameDataWithoutHistory(data, true);
        if (currentUnitNode!=null && currentUnitNode.next.data!=null){
            if (options==null){
                throw new NullPointerException();
            }
            WorldModel newModel =new WorldModel(dataCopy, currentUnitNode.next, options);
            //throw new NullPointerException();
            return newModel;
        } else {
            WorldModel newModel =new WorldModel(dataCopy, true);
            return newModel;
        }
    }

    public WorldModel generateChildWorldModelSort(){
        GameData dataCopy;
        dataCopy = GameDataUtils.cloneGameDataWithoutHistory(data, true);
        if (currentUnitNode!=null && currentUnitNode.next.data!=null){
            if (options==null){
                throw new NullPointerException();
            }
            WorldModel newModel =new WorldModel(dataCopy, currentUnitNode.next, options);
            //throw new NullPointerException();
            return newModel;
        } else {
            WorldModel newModel =new WorldModel(dataCopy, true);
            return newModel;
        }
    }

    public double getWorldHeuristic(GamePlayer player){
        int unitN=0;
        IntegerMap<UnitType> map= data.getPlayerList().getPlayerId(player.getName()).getUnitCollection().getUnitsByType();
        /*
        for (UnitType t:map.keySet()){
            t.getClass().getAnnotations()
            unitN=data.getSequence().getStep().getPlayerId().getUnitCollection().getUnitsByType()

        }
         */
        unitN=data.getSequence().getStep().getPlayerId().getUnitCollection().size();
        return unitN;
    }

    
}