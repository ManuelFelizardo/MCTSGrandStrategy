package games.strategy.triplea.ai.mctstest.OEP;

import games.strategy.engine.data.GameData;
import games.strategy.engine.data.GamePlayer;
import games.strategy.engine.data.Territory;
import games.strategy.engine.data.Unit;
import games.strategy.engine.framework.GameDataUtils;
import games.strategy.triplea.ai.mctstest.algorithm.Action;
import games.strategy.triplea.ai.mctstest.algorithm.ActionWrapper;
import games.strategy.triplea.ai.mctstest.algorithm.Mcts;
import games.strategy.triplea.ai.mctstest.algorithm.WorldModel;
import games.strategy.triplea.ai.mctstest.forwardmodel.ForwardModel;
import games.strategy.triplea.ai.mctstest.forwardmodel.MctsData;
import games.strategy.triplea.ai.pro.logging.ProLogger;
import games.strategy.triplea.ai.weak.WeakAi;
import games.strategy.triplea.delegate.remote.IMoveDelegate;
import java.util.ArrayList;
import java.util.logging.Level;
import lombok.Getter;

public class AbstractOEPAi extends WeakAi {

  private Oep oep;

  public AbstractOEPAi(final String name) {

    super(name);
    ProLogger.info("Starting ABSTRACTMCTSAI class");
  }

  @Override
  protected void move(
      final boolean nonCombat,
      final IMoveDelegate moveDel,
      final GameData data,
      final GamePlayer player) {
    super.stopGame(); // absolutely MUST call super.stopGame() first
    ProLogger.info("Starting Move phase");
    MctsData mctsData= new MctsData(data);
    mctsData.initialize(data);
    final GameData dataCopy;
    try {
      data.acquireWriteLock();
      dataCopy = GameDataUtils.cloneGameDataWithoutHistory(data, true);
    } catch (final Throwable t) {
      ProLogger.log(Level.WARNING, "Error trying to clone game data for simulating phases", t);
      throw new NullPointerException();
      //return;
    } finally {
      data.releaseWriteLock();
    }


    ProLogger.info("Selection Action");
    oep=new Oep();
    ArrayList<Action> actions=oep.run(new WorldModel(dataCopy));

    final long start = System.currentTimeMillis();
    ForwardModel.doMove(ForwardModel.attackToMove(replaceUnits(data,actions).actions, mctsData), moveDel, player, data, mctsData, false);

    ProLogger.info(
        player.getName()
            + " time for nonCombat="
            + nonCombat
            + " time="
            + (System.currentTimeMillis() - start));

  }

  public ActionWrapper replaceUnits(GameData data, ArrayList<Action> actions){
    ActionWrapper newWrapper=new ActionWrapper();
    for (Action a:actions){

      newWrapper.addMovement(data.getUnits().get(a.getU().getId()),(Territory) data.getUnitHolder(a.getT().getName(),"T"));
    }
    return newWrapper;
  }

}
