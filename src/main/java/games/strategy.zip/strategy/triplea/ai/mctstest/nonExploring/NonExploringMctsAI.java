package games.strategy.triplea.ai.mctstest.nonExploring;

import games.strategy.triplea.ai.mctstest.forwardmodel.ForwardModel;
import games.strategy.triplea.ai.mctstest.forwardmodel.MctsData;
import games.strategy.triplea.ai.pro.logging.ProLogger;

public class NonExploringMctsAI extends AbstractNonExploringMctsAi{
  public NonExploringMctsAI(String name) {

    super(name, new MctsData());
    ForwardModel.mctsAi=this;
    ProLogger.info("Starting MCTSAI class");
    currentInstance=this;
  }
}
