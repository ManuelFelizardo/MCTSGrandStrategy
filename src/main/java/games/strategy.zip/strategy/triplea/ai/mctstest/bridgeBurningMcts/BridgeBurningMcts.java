package games.strategy.triplea.ai.mctstest.bridgeBurningMcts;

import games.strategy.triplea.ai.mctstest.algorithm.Action;
import games.strategy.triplea.ai.mctstest.algorithm.ActionWrapper;
import games.strategy.triplea.ai.mctstest.algorithm.MCTSNode;
import games.strategy.triplea.ai.mctstest.algorithm.Mcts;
import games.strategy.triplea.ai.mctstest.algorithm.Reward;
import games.strategy.triplea.ai.mctstest.algorithm.WorldModel;
import games.strategy.triplea.ai.pro.logging.ProLogger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class BridgeBurningMcts extends Mcts {

  private int executionTime=100000;
  MCTSNode newInitialNode;
  public BridgeBurningMcts(WorldModel worldModel){
    super(worldModel);
  }


  @Override
  public ActionWrapper run()
  {
    this.MaxIterations = 100;
    this.MaxIterationsProcessedPerFrame = 100;
    this.newInitialNode=initialNode;
    runCount++;
    MCTSNode selectedNode;
    Reward reward;

    this.CurrentIterationsInFrame = 0;
    long iterationTime=executionTime/initialNode.state.myList.getSize();
    long startTime=System.currentTimeMillis();
    long iterationStartTime=startTime;
    while((System.currentTimeMillis()-startTime)<executionTime && this.CurrentIterationsInFrame < this.MaxIterationsProcessedPerFrame && this.CurrentIterations < this.MaxIterations)
    {
      this.CurrentDepth = 0;
      //selection and expansion



      selectedNode = this.Selection(this.newInitialNode);

      //debug info
      if(this.CurrentDepth > this.MaxSelectionDepthReached)
      {
        this.MaxSelectionDepthReached = this.CurrentDepth;
      }
      reward = this.Playout(selectedNode.state);

      //debug info
      if(this.CurrentDepth > this.MaxPlayoutDepthReached)
      {
        this.MaxPlayoutDepthReached = this.CurrentDepth;
      }
      //backpropagation

      this.Backpropagate(selectedNode, reward);

      this.CurrentIterationsInFrame++;
      this.CurrentIterations++;
      if (System.currentTimeMillis()-iterationStartTime>iterationTime){
        //this.newInitialNode=initialNode;
        iterationStartTime=0;
      }

    }

    if((System.currentTimeMillis()-startTime)<executionTime){
      //throw new NullPointerException(System.currentTimeMillis()-startTime+", "+System.currentTimeMillis()+", "+startTime+", "+this.CurrentIterationsInFrame);
    }

    if(this.CurrentIterations >= this.MaxIterations-1)
    {
      this.InProgress = false;
      ProLogger.info("mcts end return action");
      //return this.BestFinalAction(this.initialNode);
      printStructure(initialNode,runCount);
      return this.BestFinalActionWrapper(this.initialNode);
    }
    else
    {
      ProLogger.info("mcts end return null");
      throw new NullPointerException();
      //return null;
    }
  }

  @Override
  protected MCTSNode Selection(MCTSNode initialNode)
  {
    ProLogger.info("------------------------------------> Started selection phase");
    ProLogger.info("------------------------------------> root node phase - "+initialNode.state.data.getSequence().getStep().getName());
    Action nextAction;
    MCTSNode currentNode = initialNode;
    MCTSNode bestChild;


    while(!currentNode.state.isTerminal())
    {
      if(initialNode.state.data.getSequence().getRound()!=currentNode.state.data.getSequence().getRound()){
        this.CurrentDepth++;
        nextAction = currentNode.state.getNextAction();

        if(nextAction != null )
        {
          ProLogger.info("------------------------------------> expanded new node");
          if(nextAction != null){
            ProLogger.info(nextAction.toString());
          } else {
            ProLogger.info("null action");
          }
          return this.Expand(currentNode, nextAction);

        }
      }

      bestChild = this.bestUCTChild(currentNode);
      if (bestChild == null)
      {
        ProLogger.info("------------------------------------> returned final tree node");
        if (currentNode.action==null){
          ProLogger.info("------------------------------------> null action");
        } else {
          ProLogger.info(currentNode.action.toString());
        }
        ProLogger.info("------------------------------------> number of child nodes - "+currentNode.ChildNodes.size());
        return currentNode;

      }
      else
      {
        ProLogger.info("------------------------------------> selected new tree node");
        currentNode = bestChild;
        ProLogger.info(currentNode.action.toString());
        ProLogger.info("------------------------------------> best child phase - "+currentNode.state.data.getSequence().getStep().getName());
      }

    }

    return currentNode;
  }

  @Override
  protected Reward Playout(WorldModel initialPlayoutState)
  {
    ArrayList<Action> executableActions;
    int randomIndex;
    WorldModel state = initialPlayoutState.generateChildWorldModel();
    int i=0;
    while(!state.isTerminal() || i<15)
    {
      i++;
      executableActions = state.getExecutableActions();
      if(executableActions.size() > 0)
      {
        this.CurrentDepth++;
        executableActions.get(0).applyActionEffectsSingular(state);
        //Action.throwshit();
      }
      else
      {
        break;
      }
    }

    // meter reward
    //return new Reward(0, state.getScore());
    return new Reward(0, Math.random());
  }
}
