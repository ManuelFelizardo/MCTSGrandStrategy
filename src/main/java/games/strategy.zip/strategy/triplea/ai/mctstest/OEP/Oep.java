package games.strategy.triplea.ai.mctstest.OEP;

import games.strategy.triplea.ai.mctstest.algorithm.Action;
import games.strategy.triplea.ai.mctstest.algorithm.ActionWrapper;
import games.strategy.triplea.ai.mctstest.algorithm.WorldModel;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Oep {

  static final int GENE_SIZE=25;
  static final int executionTime=10000;
  static final double mutationP=0.5;

  static class Genome implements Comparable<Genome>{
    ArrayList<Action> actions;
    int visits=0;
    double value=0;


    Genome(){

    }
    Genome(WorldModel state){
      this.actions=generateRandomActions(state);

    }

    Genome(ArrayList<Action> actions){
      this.actions=actions;
    }

    public ArrayList<Action> generateRandomActions(WorldModel state){
      //implementar random actions
      return new ArrayList<>();
    }

    public void executeActions(WorldModel newState){
      for(Action a:actions){
        a.applyActionEffectsSingular(newState);
      }
      Action finalA= new Action(null, null);
      finalA.applyActionEffectsSingular(newState);
    }

    @Override
    public int compareTo(final Genome g) {
      if(value>g.value){
        return 1;
      } else if (value==g.value){
        return 0;
      } else {
        return -1;
      }

    }
  }

  public static double eval(WorldModel state){
    return Math.random();
  }

  public ArrayList<Action> run(WorldModel state){
    List<Genome> genes= new ArrayList<>();
    init(genes, state);
    float startTime=System.currentTimeMillis();
    while (true){
      for(Genome g:genes){
        WorldModel newState=state.generateChildWorldModel();
        g.executeActions(newState);
        if (g.visits>0){
          g.value=eval(newState);
        }
        g.visits++;
      }
      if (System.currentTimeMillis()-startTime<executionTime){
        break;
      }
      Collections.sort(genes,Collections.reverseOrder());
      int size=genes.size();
      List<Genome> newGenes= genes.subList(0,size/2);
      genes=procreate(newGenes);
    }
    return genes.get(0).actions;

  }

  public List<Genome> procreate(List<Genome> genes){
    ArrayList<Genome> newGenes=new ArrayList<>();
    for(Genome g:genes){
      ArrayList<Action> newActions=new ArrayList<>();
      Genome otherGenome=genes.get((int)(Math.random()*genes.size()));
      for(int i=0;i<g.actions.size();i++){
        if(Math.random()>0.5){
          newActions.add(g.actions.get(i));
        } else {
          newActions.add(otherGenome.actions.get(i));
        }
      }

      if(Math.random()>mutationP){
        //Gerar ação random e mudar
      }
      newGenes.add(new Genome(newActions));

    }
    genes.addAll(newGenes);
    return genes;
  }

  public void init(List<Genome> genes, WorldModel state){
    for (int i=0;i<GENE_SIZE;i++){
      WorldModel newState= state.generateChildWorldModel();
      Genome g= new Genome(state);
      genes.add(g);
    }
  }
}
