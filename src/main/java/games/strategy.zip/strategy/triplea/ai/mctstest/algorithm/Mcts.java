package games.strategy.triplea.ai.mctstest.algorithm;

import games.strategy.triplea.ai.pro.logging.ProLogger;
import java.io.File;
import java.io.IOException;
import java.io.Writer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Random;

public class Mcts{
    public static final float C = 1.4f;
    public boolean InProgress;
    public int MaxIterations ;
    public int MaxIterationsProcessedPerFrame ;
    public int MaxPlayoutDepthReached ;
    public int MaxSelectionDepthReached ;
    public float TotalProcessingTime ;
    public MCTSNode BestFirstChild ;
    public ArrayList<Action> BestActionSequence ;
    public static int runCount=0;



    protected int CurrentIterations ;
    protected int CurrentIterationsInFrame ;
    protected int CurrentDepth ;

    protected WorldModel worldModel ;
    protected MCTSNode initialNode ;
    protected Random RandomGenerator ;



    public Mcts(WorldModel worldModel){
        this.InProgress = false;
        this.worldModel = worldModel;
        this.MaxIterations = 25;
        this.MaxIterationsProcessedPerFrame = 25;
        this.RandomGenerator = new Random();
    }


    public void initializeMCTSearch()
    {
        this.MaxPlayoutDepthReached = 0;
        this.MaxSelectionDepthReached = 0;
        this.CurrentIterations = 0;
        this.CurrentIterationsInFrame = 0;
        this.TotalProcessingTime = 0.0f;
        this.initialNode = new MCTSNode(this.worldModel, this.worldModel.player, null);
        this.InProgress = true;
        this.BestFirstChild = null;
        this.BestActionSequence = new ArrayList<Action>();
    }

    public ActionWrapper run()
    {
        runCount++;
        MCTSNode selectedNode;
        Reward reward;

        this.CurrentIterationsInFrame = 0;

        while(this.CurrentIterationsInFrame < this.MaxIterationsProcessedPerFrame && this.CurrentIterations < this.MaxIterations)
        {
            this.CurrentDepth = 0;
            //selection and expansion



            selectedNode = this.Selection(this.initialNode);

            //debug info
            if(this.CurrentDepth > this.MaxSelectionDepthReached)
            {
                this.MaxSelectionDepthReached = this.CurrentDepth;
            }
            //ProLogger.info("post selection action is null: " + (selectedNode.action==null));
            //ProLogger.info("post selection action details : "+ selectedNode.action.getU().toString() + ", "+selectedNode.action.getT().toString());
            //playout
            reward = this.Playout(selectedNode.state);

            //debug info
            if(this.CurrentDepth > this.MaxPlayoutDepthReached)
            {
                this.MaxPlayoutDepthReached = this.CurrentDepth;
            }
            //backpropagation

            this.Backpropagate(selectedNode, reward);

            this.CurrentIterationsInFrame++;
            this.CurrentIterations++;
        }


        if(this.CurrentIterations >= this.MaxIterations-1)
        {
            this.InProgress = false;
            ProLogger.info("mcts end return action");
            //return this.BestFinalAction(this.initialNode);
            printStructure(initialNode,runCount);
            return this.BestFinalActionWrapper(this.initialNode);
        }
        else
        {
            ProLogger.info("mcts end return null");
            throw new NullPointerException();
            //return null;
        }
    }

    protected MCTSNode Selection(MCTSNode initialNode)
    {
        ProLogger.info("------------------------------------> Started selection phase");
        ProLogger.info("------------------------------------> root node phase - "+initialNode.state.data.getSequence().getStep().getName());
        Action nextAction;
        MCTSNode currentNode = initialNode;
        MCTSNode bestChild;


        while(!currentNode.state.isTerminal())
        {

            this.CurrentDepth++;
            nextAction = currentNode.state.getNextAction();

            if(nextAction != null )
            {

                /*
                if (nextAction.getU() ==null) {
                    throw new NullPointerException();
                }
                if (nextAction.getT() ==null) {
                    throw new NullPointerException();
                }
                 */
                //throw new NullPointerException();
                ProLogger.info("------------------------------------> expanded new node");
                if(nextAction != null){
                    ProLogger.info(nextAction.toString());
                } else {
                    ProLogger.info("null action");
                }
                return this.Expand(currentNode, nextAction);

            }
            else
            {
                bestChild = this.bestUCTChild(currentNode);
                if (bestChild == null)
                {
                    ProLogger.info("------------------------------------> returned final tree node");
                    if (currentNode.action==null){
                        ProLogger.info("------------------------------------> null action");
                    } else {
                        ProLogger.info(currentNode.action.toString());
                    }
                    ProLogger.info("------------------------------------> number of child nodes - "+currentNode.ChildNodes.size());
                    return currentNode;

                }
                else
                {
                    ProLogger.info("------------------------------------> selected new tree node");
                    currentNode = bestChild;
                    ProLogger.info(currentNode.action.toString());
                    ProLogger.info("------------------------------------> best child phase - "+currentNode.state.data.getSequence().getStep().getName());
                }
            }
        }

        return currentNode;
    }

    protected Reward Playout(WorldModel initialPlayoutState)
    {
        ArrayList<Action> executableActions;
        int randomIndex;
        WorldModel state = initialPlayoutState.generateChildWorldModel();
        int i=0;
        while(!state.isTerminal() || i<15)
        {
            i++;
            executableActions = state.getExecutableActions();
            if(executableActions.size() > 0)
            {
                this.CurrentDepth++;
                randomIndex = this.RandomGenerator.nextInt(executableActions.size());
                executableActions.get(randomIndex).applyActionEffectsSingular(state);
                //Action.throwshit();
            }
            else
            {
                break;
            }
        }

        // meter reward
        //return new Reward(0, state.getScore());
        return new Reward(0, Math.random());
    }

    protected void Backpropagate(MCTSNode node, Reward reward)
    {
        ProLogger.info("backpropagate");
        while(node != null)
        {
            ProLogger.info("iterated over "+node.action);
            node.N++;
            node.Q += reward.getRewardForNode(node);
            ProLogger.info("new n - "+node.N);
            node = node.parent;
        }
    }

    protected MCTSNode Expand(MCTSNode parent, Action action)
    {

        WorldModel newState = parent.state.generateChildWorldModel();
        action.applyActionEffectsSingular(newState);

        var child = new MCTSNode(newState, newState.player, action);
        child.parent=parent;

        parent.ChildNodes.add(child);
        ProLogger.info("added child Node");

        return child;
    }

    protected MCTSNode bestUCTChild(MCTSNode node)
    {
        float UCTValue;
        float bestUCT = -10000000000f;
        MCTSNode bestNode = null;
        for(MCTSNode child : node.ChildNodes)
        {

            if (child==null){
                throw new NullPointerException();
            }
            if (child.parent==null){
                throw new NullPointerException();
            }
            UCTValue = (child.Q / child.N) + games.strategy.triplea.ai.mctstest.algorithm.Mcts.C * (float)Math.sqrt(Math.log(child.parent.N) / child.N);
            if (UCTValue > bestUCT)
            {
                ProLogger.info("new best");
                bestUCT = UCTValue;
                bestNode = child;
            }

            ProLogger.info("parent N " + child.parent.N);
            //ProLogger.info("child Q " + child.Q);
            ProLogger.info("child N " + child.N);
            //ProLogger.info("uct value - "+UCTValue);
            //ProLogger.info("best uct - "+bestUCT);

        }

        return bestNode;
    }

    //this method is very similar to the bestUCTChild, but it is used to return the final action of the MCTS search, and so we do not care about
    //the exploration factor
    protected MCTSNode BestChild(MCTSNode node)
    {
        float averageQ;
        float bestAverageQ = Integer.MIN_VALUE;
        MCTSNode bestNode = null;
        ProLogger.info("number of childnodes " + node.ChildNodes.size());

        ProLogger.info("number of childnodes " + node.ChildNodes.size());
        for(MCTSNode child : node.ChildNodes)
        {
            ProLogger.info("child N " + child.Q);
            ProLogger.info("child Q " + child.N);
            averageQ = (child.Q / child.N);
            ProLogger.info("average Q " + averageQ);
            ProLogger.info("bestaverage Q " + bestAverageQ);
            if (averageQ > bestAverageQ)
            {
                ProLogger.info("merda ");
                bestAverageQ = averageQ;
                bestNode = child;
            }
        }

        return bestNode;
    }


    protected Action BestFinalAction(MCTSNode node)
    {
        MCTSNode bestChild = this.BestChild(node);
        if (bestChild == null) return null;

        this.BestFirstChild = bestChild;

        //this is done for debugging proposes only
        this.BestActionSequence = new ArrayList<Action>();
        this.BestActionSequence.add(bestChild.action);
        node = bestChild;

        while(!node.state.isTerminal())
        {
            bestChild = this.BestChild(node);
            if (bestChild == null) break;
            this.BestActionSequence.add(bestChild.action);
            node = bestChild;    
        }

        return this.BestFirstChild.action;
    }

    protected ActionWrapper BestFinalActionWrapper(MCTSNode node)
    {
        ProLogger.info("starting best final action wrapper");
        MCTSNode bestChild = this.BestChild(node);
        if (bestChild == null) return null;

        this.BestFirstChild = bestChild;

        //this is done for debugging proposes only
        this.BestActionSequence = new ArrayList<Action>();
        ActionWrapper end=new ActionWrapper();
        this.BestActionSequence.add(bestChild.action);
        node = bestChild;
        ProLogger.info("starting iterating");
        while(node.action.intermediate)
        {
            ProLogger.info("action  u - "+bestChild.action.getU()+", t - "+bestChild.action.getT());
            bestChild = this.BestChild(node);
            if (bestChild == null) break;
            this.BestActionSequence.add(bestChild.action);
            ProLogger.info("2");
            end.addMovement(bestChild.action.u,bestChild.action.t);
            node = bestChild;
        }
        ProLogger.info("best child  u - "+bestChild.action.u+", t- "+bestChild.action.t);
        end.addMovement(bestChild.action.u,bestChild.action.t);
        this.BestActionSequence.add(bestChild.action);

        return end;
    }

    public void printStructure(MCTSNode initialNode, int i){

        try {
            File myObj = new File("Estrutura"+i+".txt");
            Writer myWriter = Files.newBufferedWriter(myObj.toPath(), Charset.defaultCharset());
            printRecursion(initialNode,myWriter, "    ");
            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
            System.out.println("Deu erro 1");
        }
    }

    public void printRecursion(MCTSNode node, Writer writer, String ident){
        try {
            for (MCTSNode n : node.ChildNodes) {
                if (n.action!=null){
                    writer.write("\n"+ident+n.action+" -> "+ n.state.data.getSequence().getStep().getName());
                    //writer.write("\n"+ident + node.action.getU()+ " to "+node.action.getT()+" -> " + n.state.data.getSequence().getStep().getName());
                } else {
                    writer.write("\n"+ident + "null action -> " + n.state.data.getSequence().getStep().getName());
                }

                printRecursion(n, writer, ident + "    ");
            }
        } catch (IOException e){
            System.out.println("Deu erro 2");
        }
    }

}


